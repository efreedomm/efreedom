"use client"
import { motion } from "framer-motion"
import { MessageSquare, Clock, CheckCircle, TrendingUp, Mail } from "lucide-react"

export default function AutomatedFollowUpsClient() {
  return (
    <main className="bg-black min-h-screen relative overflow-hidden">
      {Array.from({ length: 20 }).map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 bg-white/20 rounded-full animate-float"
          style={{
            left: `${Math.random() * 100}%`,
            bottom: `-${Math.random() * 20}px`,
            animationDelay: `${Math.random() * 5}s`,
            animationDuration: `${15 + Math.random() * 10}s`,
          }}
        />
      ))}

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-32 pb-20 md:pt-40 md:pb-32">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.03),transparent_70%)]" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="font-heading text-5xl font-bold tracking-wide text-white md:text-7xl lg:text-8xl">
              Leads Ghost — We Bring Them Back
            </h1>
            <p className="mt-6 text-xl text-white/80 max-w-3xl mx-auto md:text-2xl">
              Our automated text & email follow-ups turn dead quotes into booked jobs — all on autopilot.
            </p>

            <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)] text-lg"
              >
                See 90-sec Demo →
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* The Problem */}
      <section className="py-20 md:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="font-heading text-4xl font-bold text-white md:text-6xl mb-6">The Problem</h2>
            <p className="text-xl text-white/70 max-w-3xl mx-auto">
              You send the quote. Then... crickets. Most leads never reply, and you're too busy to chase them down.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: MessageSquare,
                title: "80% Never Reply",
                description: "Most leads ghost after getting a quote — even if they're interested.",
              },
              {
                icon: Clock,
                title: "No Time to Follow Up",
                description: "You're on-site working. Who has time to send reminder texts?",
              },
              {
                icon: TrendingUp,
                title: "Lost Revenue",
                description: "Every ghosted lead is money left on the table.",
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gradient-to-br from-red-900/20 to-red-950/10 backdrop-blur-sm border border-red-500/20 rounded-xl p-8 hover:border-red-500/40 transition-all duration-300"
              >
                <item.icon className="w-12 h-12 text-red-400 mb-4" />
                <h3 className="text-2xl font-bold text-white mb-3">{item.title}</h3>
                <p className="text-white/70">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* The Fix */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-transparent to-black/50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="font-heading text-4xl font-bold text-white md:text-6xl mb-6">The Fix</h2>
            <p className="text-xl text-white/70 max-w-3xl mx-auto">
              Smart AI follow-ups with reminders, discounts, and thank-yous — all automated.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {[
              {
                icon: Mail,
                title: "Automated Text & Email Sequences",
                description:
                  "Day 1: 'Thanks for your interest!' Day 3: 'Still thinking it over?' Day 7: 'Limited-time discount inside.'",
              },
              {
                icon: MessageSquare,
                title: "Personalized Messages",
                description: "AI customizes each follow-up based on the job type, quote amount, and lead behavior.",
              },
              {
                icon: Clock,
                title: "Perfect Timing",
                description: "Sends follow-ups at optimal times when leads are most likely to respond.",
              },
              {
                icon: CheckCircle,
                title: "Auto-Books Appointments",
                description: "When they reply 'yes,' the system books them directly into your calendar.",
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm border border-white/20 rounded-xl p-8 hover:border-white/40 transition-all duration-300"
              >
                <item.icon className="w-12 h-12 text-white mb-4" />
                <h3 className="text-2xl font-bold text-white mb-3">{item.title}</h3>
                <p className="text-white/70">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* The Result */}
      <section className="py-20 md:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h2 className="font-heading text-4xl font-bold text-white md:text-6xl mb-6">The Result</h2>
            <p className="text-3xl text-white font-bold mb-8">Up to 2x More Booked Jobs</p>
            <p className="text-xl text-white/70 max-w-3xl mx-auto">
              Businesses using eFreedom's automated follow-ups recover 30-50% of leads that would have been lost
              forever.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-16 grid md:grid-cols-3 gap-8 max-w-5xl mx-auto"
          >
            {[
              { stat: "2x", label: "More Booked Jobs" },
              { stat: "30-50%", label: "Lead Recovery Rate" },
              { stat: "0 Hours", label: "Manual Follow-Up Time" },
            ].map((item, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-white/10 to-transparent backdrop-blur-sm border border-white/20 rounded-xl p-8 text-center"
              >
                <div className="text-5xl font-bold text-white mb-2">{item.stat}</div>
                <div className="text-white/70">{item.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Demo - Animated Timeline */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-transparent to-black/50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="font-heading text-4xl font-bold text-white md:text-6xl mb-6">How It Works</h2>
            <p className="text-xl text-white/70 max-w-3xl mx-auto">
              Watch how a dead lead becomes a booked job in 7 days
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            {[
              {
                day: "Day 1",
                title: "Lead Receives Quote",
                message: "Thanks for your interest! Here's your quote for $2,500. Ready to book?",
                status: "Sent",
              },
              {
                day: "Day 3",
                title: "First Follow-Up",
                message: "Hi John! Just checking in — any questions about the quote?",
                status: "Sent",
              },
              {
                day: "Day 5",
                title: "Value Reminder",
                message: "Quick reminder: We're booking fast this month. Want to lock in your spot?",
                status: "Sent",
              },
              {
                day: "Day 7",
                title: "Discount Offer",
                message: "Last call! Book this week and save 10% ($250 off). Ready to schedule?",
                status: "Replied: 'Yes!'",
              },
              {
                day: "Day 7",
                title: "Auto-Booked",
                message: "Perfect! You're booked for Tuesday at 10am. See you then!",
                status: "Job Booked ✓",
              },
            ].map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                className="relative mb-8 last:mb-0"
              >
                <div className="flex items-start gap-6">
                  {/* Timeline dot */}
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center font-bold ${
                        step.status.includes("Booked")
                          ? "bg-white text-black"
                          : step.status.includes("Replied")
                            ? "bg-green-500 text-white"
                            : "bg-white/10 text-white"
                      }`}
                    >
                      {index + 1}
                    </div>
                    {index < 4 && <div className="w-0.5 h-16 bg-white/20 mt-2" />}
                  </div>

                  {/* Content */}
                  <div className="flex-1 bg-gradient-to-br from-white/5 to-transparent backdrop-blur-sm border border-white/10 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white font-semibold">{step.day}</span>
                      <span
                        className={`text-sm px-3 py-1 rounded-full ${
                          step.status.includes("Booked")
                            ? "bg-white/20 text-white"
                            : step.status.includes("Replied")
                              ? "bg-green-500/20 text-green-400"
                              : "bg-white/10 text-white/70"
                        }`}
                      >
                        {step.status}
                      </span>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">{step.title}</h3>
                    <p className="text-white/70 italic">"{step.message}"</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 md:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-gradient-to-br from-white/10 to-transparent backdrop-blur-sm border border-white/20 rounded-2xl p-12 text-center"
          >
            <h2 className="font-heading text-4xl font-bold text-white md:text-6xl mb-6">Start Recovering Lost Jobs</h2>
            <p className="text-xl text-white/70 max-w-2xl mx-auto mb-8">
              Stop losing leads to silence. Let eFreedom's AI follow-ups turn dead quotes into booked jobs —
              automatically.
            </p>
            <a
              href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)] text-lg"
            >
              Book a Free Call →
            </a>
          </motion.div>
        </div>
      </section>

      <style jsx>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0) translateX(0);
            opacity: 0;
          }
          10% {
            opacity: 0.2;
          }
          90% {
            opacity: 0.2;
          }
          100% {
            transform: translateY(-100vh) translateX(${Math.random() * 100 - 50}px);
            opacity: 0;
          }
        }
        .animate-float {
          animation: float linear infinite;
        }
      `}</style>
    </main>
  )
}
