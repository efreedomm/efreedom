import type { Metadata } from "next"
import AutomatedFollowUpsClient from "./_components/AutomatedFollowUpsClient"

export const metadata: Metadata = {
  title: "Automated Follow-Ups for Businesses | AI Quote Reminders | eFreedom",
  description:
    "Turn dead quotes into booked jobs with automated text & email follow-ups. Smart AI reminders, discounts, and thank-yous on autopilot. Book 2x more jobs with eFreedom's automated follow up software.",
  keywords: [
    "automated follow ups",
    "AI quote reminders",
    "text follow up software",
    "lead follow up",
    "automated text reminders",
    "email follow up automation",
  ],
}

export default function AutomatedFollowUpsPage() {
  return <AutomatedFollowUpsClient />
}
