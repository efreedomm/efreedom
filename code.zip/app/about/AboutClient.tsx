"use client"

export default function AboutClient() {
  return (
    // <CHANGE> Changed background from navy to black
    <main className="min-h-screen bg-black pt-16 relative overflow-hidden">
      {/* <CHANGE> Added floating particles background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white/20 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${15 + Math.random() * 10}s`,
            }}
          />
        ))}
      </div>

      <section className="py-20 px-4 relative z-10">
        <div className="mx-auto max-w-4xl">
          {/* <CHANGE> Updated heading to eFreedom */}
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-8 text-center">About eFreedom</h1>

          <div className="prose prose-invert prose-lg max-w-none">
            <p className="text-xl text-white/80 mb-8 text-center">
              We're on a mission to help businesses grow by turning missed calls into booked jobs.
            </p>

            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-8 mb-8">
              <h2 className="text-3xl font-bold text-white mb-4">Our Story</h2>
              {/* <CHANGE> Updated company name to eFreedom */}
              <p className="text-white/80 mb-4">
                {"eFreedom was founded with a simple belief: every business deserves access to the same cutting-edge marketing technology that Fortune 500 companies use.\nMedawar & Singh have gathered the best team and tech to make these systems possible."}
              </p>
              <p className="text-white/80">
                We've helped businesses across industries transform their marketing with AI-powered automation, smart
                CRM systems, and proven digital strategies that work 24/7.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-8 mb-8">
              <h2 className="text-3xl font-bold text-white mb-4">What We Do</h2>
              <p className="text-white/80 mb-4">
                We specialize in building complete marketing systems that never sleep:
              </p>
              <ul className="text-white/80 space-y-2 list-disc list-inside">
                <li>AI-powered call answering and lead capture that works 24/7</li>
                <li>Automated follow-up systems that convert more leads</li>
                <li>Local SEO to dominate your service area</li>
                <li>Digital advertising that actually generates ROI</li>
                <li>Website development optimized for conversions</li>
                <li>Review generation and reputation management</li>
                <li>SEO on ChatGPT (GEO) for next-generation visibility</li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-8 mb-8">
              <h2 className="text-3xl font-bold text-white mb-4">Why Choose Us</h2>
              <p className="text-white/80 mb-4">
                We're not just another marketing agency. We're growth specialists who understand your unique challenges:
              </p>
              <ul className="text-white/80 space-y-2 list-disc list-inside">
                <li>We focus on ROI, not vanity metrics</li>
                <li>We build systems that work 24/7, even when you're busy</li>
                <li>We help anyone willing to help their business grow</li>
                <li>We use cutting-edge AI technology to give you an unfair advantage</li>
              </ul>
            </div>

            <div className="text-center mt-12">
              <h2 className="text-3xl font-bold text-white mb-6">Ready to Grow Your Business?</h2>
              <a
                href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
                target="_blank"
                rel="noopener noreferrer"
                // <CHANGE> Changed button from gold to white with black text
                className="inline-block px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg"
              >
                Book Your Free Strategy Call
              </a>
            </div>
          </div>
        </div>
      </section>

      <style jsx>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0) translateX(0);
            opacity: 0;
          }
          10% {
            opacity: 0.3;
          }
          50% {
            transform: translateY(-100vh) translateX(20px);
            opacity: 0.2;
          }
          90% {
            opacity: 0.1;
          }
        }
        .animate-float {
          animation: float linear infinite;
        }
      `}</style>
    </main>
  )
}
