import type { Metadata } from "next"
import AboutClient from "./AboutClient"

export const metadata: Metadata = {
  title: "About eFreedom | AI-Powered Business Growth Solutions",
  description:
    "eFreedom specializes in AI-powered automation and digital marketing to help businesses grow. We turn missed opportunities into booked jobs with cutting-edge technology.",
}

export default function AboutPage() {
  return <AboutClient />
}
