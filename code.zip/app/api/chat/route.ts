import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { messages } = await request.json()

    console.log("[v0] Received messages:", messages)

    if (!Array.isArray(messages)) {
      return NextResponse.json({ error: "Messages must be an array" }, { status: 400 })
    }

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: `You are a helpful AI assistant for eFreedom, a marketing automation company that helps businesses turn missed opportunities into revenue.

**Our 7 Core Solutions:**
• AI Receptionist - 24/7 automated call answering
• Automated Follow-Ups - Smart text & email sequences
• Digital Ads & Funnels - Conversion-focused Meta & Google ads
• Local SEO - Google Business optimization
• ChatGPT SEO (GEO) - Optimize for AI search engines
• Website Development - Fast, conversion-optimized sites
• Reviews Engine - Automated review requests

**Key Benefits:**
• Replace 15+ tools, save $3,300+/month
• One unified AI revenue OS
• 2-4x more booked appointments within 90 days
• We handle the tech, you focus on growth

**IMPORTANT INSTRUCTIONS:**
1. NEVER mention specific prices or dollar amounts
2. When asked about pricing, say: "Our pricing is customized based on your business needs. I'd recommend booking a free strategy call so we can show you the system and create a plan that fits your goals. Would you like me to help you schedule that?"
3. Keep responses SHORT and ORGANIZED:
   - Use bullet points (•) for lists
   - Add line breaks between sections
   - Max 3-4 sentences per paragraph
   - Get to the point quickly
4. Be persuasive but natural - focus on solving real problems:
   - Missed calls & ghosted leads
   - No tracking or wasted ad spend
   - Bad reviews & outdated websites
5. Always end with a soft call-to-action like booking a call or asking if they have questions

Format your responses with clear structure and spacing for easy reading.`,
          },
          ...messages,
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("[v0] OpenAI API error:", errorData)
      throw new Error("OpenAI API request failed")
    }

    const data = await response.json()
    console.log("[v0] OpenAI response received")

    const assistantMessage = data.choices[0]?.message?.content || "I'm sorry, I couldn't generate a response."

    return NextResponse.json({ message: assistantMessage })
  } catch (error) {
    console.error("[v0] Chat API error:", error)
    return NextResponse.json({ error: "Failed to process chat request" }, { status: 500 })
  }
}
