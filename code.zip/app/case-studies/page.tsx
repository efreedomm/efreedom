import type { Metadata } from "next"
import CaseStudiesClient from "./case-studies-client"

export const metadata: Metadata = {
  title: "Case Studies | Real Business Results | eFreedom",
  description:
    "See real results from businesses who transformed their growth with eFreedom. Proven marketing strategies that generate leads and increase revenue.",
}

export default function CaseStudiesPage() {
  return <CaseStudiesClient />
}
