import type { Metadata } from "next"
import AIReceptionistClientPage from "./ai-receptionist-client"

export const metadata: Metadata = {
  title: "AI Receptionist | 24/7 Automated Call Answering | eFreedom",
  description:
    "Never miss a call again. eFreedom's AI receptionist answers, qualifies, and books appointments automatically for your business. AI call answering with automated booking.",
  keywords: [
    "AI receptionist",
    "AI call answering",
    "automated appointment booking",
    "business call answering service",
    "AI phone system",
    "24/7 AI receptionist",
  ],
}

export default function AIReceptionistPage() {
  return <AIReceptionistClientPage />
}
