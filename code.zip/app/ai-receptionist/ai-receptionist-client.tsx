"use client"

import { Phone, Clock, CheckCircle, TrendingUp, MessageSquare, Mic } from "lucide-react"

export default function AIReceptionistClientPage() {
  return (
    <main className="bg-black relative">
      <div className="fixed inset-0 pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full opacity-30"
            style={{
              left: `${Math.random() * 100}%`,
              bottom: `-${Math.random() * 20}%`,
              animation: `float ${5 + Math.random() * 10}s linear infinite`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
      </div>
      <style jsx>{`
        @keyframes float {
          to {
            transform: translateY(-100vh);
            opacity: 0;
          }
        }
      `}</style>

      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden pt-24 pb-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.05),transparent_70%)]" />

        <div className="relative mx-auto max-w-5xl px-6 text-center">
          <h1 className="font-heading text-5xl md:text-7xl font-bold text-white mb-6">Never Miss a Call Again</h1>
          <p className="text-xl md:text-2xl text-white/80 mb-8 max-w-3xl mx-auto text-balance">
            Our 24/7 AI receptionist answers, qualifies, and books jobs automatically — even while you're on-site.
          </p>
          <a
            href="#demo"
            className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)]"
          >
            <Mic className="w-5 h-5" />
            See 90-sec Demo
          </a>
        </div>
      </section>

      {/* The Problem */}
      <section className="py-20 px-6 relative">
        <div className="mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">The Problem</h2>
            <p className="text-xl text-white/70">Every missed call is money left on the table</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Phone,
                title: "Missed Calls",
                description: "You're on a job site, can't answer. Customer calls your competitor instead.",
              },
              {
                icon: Clock,
                title: "Lost Jobs",
                description: "By the time you call back, they've already booked someone else.",
              },
              {
                icon: TrendingUp,
                title: "No Time",
                description: "You're too busy working to answer phones, but you need those calls to grow.",
              },
            ].map((problem, index) => (
              <div
                key={index}
                className="relative p-6 rounded-xl bg-gradient-to-br from-red-900/20 to-red-950/10 border border-red-500/20 backdrop-blur-sm"
              >
                <problem.icon className="w-12 h-12 text-red-400 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">{problem.title}</h3>
                <p className="text-white/70">{problem.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* The Fix */}
      <section className="py-20 px-6 bg-gradient-to-b from-transparent to-black/50 relative">
        <div className="mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">The Fix</h2>
            <p className="text-xl text-white">eFreedom AI works while you work</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              {[
                {
                  step: "1",
                  title: "Answers Instantly",
                  description: "AI picks up every call in under 2 rings, 24/7/365.",
                },
                {
                  step: "2",
                  title: "Captures Info",
                  description: "Gets name, job details, location, and urgency level.",
                },
                {
                  step: "3",
                  title: "Qualifies Leads",
                  description: "Asks the right questions to filter serious buyers from tire-kickers.",
                },
                {
                  step: "4",
                  title: "Books Jobs",
                  description: "Syncs with your calendar and books appointments automatically.",
                },
              ].map((fix) => (
                <div
                  key={fix.step}
                  className="flex gap-4 p-6 rounded-xl bg-gradient-to-br from-white/10 to-transparent border border-white/20 backdrop-blur-sm"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-white text-black font-bold text-xl flex items-center justify-center">
                    {fix.step}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">{fix.title}</h3>
                    <p className="text-white/70">{fix.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-center">
              <div className="relative w-full max-w-md aspect-square">
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent rounded-full blur-3xl" />
                <div className="relative bg-black/80 backdrop-blur-md border border-white/30 rounded-2xl p-8 shadow-2xl">
                  <div className="text-center">
                    <Phone className="w-20 h-20 text-white mx-auto mb-6 animate-pulse" />
                    <p className="text-white/90 text-lg mb-4">Incoming Call...</p>
                    <div className="space-y-3">
                      <div className="bg-white/10 rounded-lg p-3 text-left">
                        <p className="text-white/70 text-sm">Caller: John Smith</p>
                      </div>
                      <div className="bg-white/10 rounded-lg p-3 text-left">
                        <p className="text-white/70 text-sm">Need: Plumbing repair</p>
                      </div>
                      <div className="bg-white/10 rounded-lg p-3 text-left">
                        <p className="text-white/70 text-sm">Status: Qualified ✓</p>
                      </div>
                      <div className="bg-white/20 rounded-lg p-3 text-left">
                        <p className="text-white font-semibold text-sm">Booked: Tomorrow 2PM</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* The Result */}
      <section className="py-20 px-6 relative">
        <div className="mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">The Result</h2>
            <p className="text-xl text-white/70">More jobs, less stress, zero missed opportunities</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: CheckCircle,
                title: "More Booked Jobs",
                stat: "+35%",
                description: "Average increase in booked appointments",
              },
              {
                icon: Clock,
                title: "Less Wasted Time",
                stat: "5+ hrs/week",
                description: "Saved on phone tag and callbacks",
              },
              {
                icon: TrendingUp,
                title: "Higher Revenue",
                stat: "$12K+/mo",
                description: "Average additional revenue captured",
              },
            ].map((result, index) => (
              <div
                key={index}
                className="relative p-8 rounded-xl bg-gradient-to-br from-white/10 to-transparent border border-white/20 backdrop-blur-sm text-center"
              >
                <result.icon className="w-12 h-12 text-white mx-auto mb-4" />
                <div className="text-4xl font-bold text-white mb-2">{result.stat}</div>
                <h3 className="text-xl font-bold text-white mb-2">{result.title}</h3>
                <p className="text-white/70 text-sm">{result.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <section id="demo" className="py-20 px-6 bg-gradient-to-b from-black/50 to-transparent relative">
        <div className="mx-auto max-w-5xl">
          <div className="text-center mb-12">
            <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">See It In Action</h2>
            <p className="text-xl text-white/70">Watch how our AI handles a real customer call</p>
          </div>

          <div className="relative bg-black/80 backdrop-blur-md border border-white/30 rounded-2xl p-8 shadow-2xl">
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/10">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span className="text-white/70 text-sm ml-2">AI Receptionist Demo</span>
            </div>

            <div className="space-y-4 max-h-96 overflow-y-auto">
              {[
                { sender: "customer", text: "Hi, I need a plumber ASAP. My kitchen sink is leaking everywhere." },
                {
                  sender: "ai",
                  text: "I understand this is urgent. I can help you right away. Can I get your name and address?",
                },
                { sender: "customer", text: "John Smith, 123 Main Street, Burbank." },
                {
                  sender: "ai",
                  text: "Thanks John. Is this a residential or commercial property? And when did the leak start?",
                },
                { sender: "customer", text: "Residential. Started this morning, getting worse." },
                {
                  sender: "ai",
                  text: "Got it. We have availability today at 2PM or tomorrow at 9AM. Which works better for you?",
                },
                { sender: "customer", text: "Today at 2PM would be perfect." },
                {
                  sender: "ai",
                  text: "Perfect! I've booked you for today at 2PM. You'll receive a confirmation text with the technician's details. Is there anything else I can help with?",
                },
              ].map((message, index) => (
                <div key={index} className={`flex ${message.sender === "ai" ? "justify-start" : "justify-end"}`}>
                  <div
                    className={`max-w-[80%] p-4 rounded-lg ${
                      message.sender === "ai"
                        ? "bg-white/20 border border-white/30"
                        : "bg-white/10 border border-white/20"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      {message.sender === "ai" ? (
                        <MessageSquare className="w-4 h-4 text-white" />
                      ) : (
                        <Phone className="w-4 h-4 text-white/70" />
                      )}
                      <span className="text-xs text-white/50">{message.sender === "ai" ? "AI" : "Customer"}</span>
                    </div>
                    <p className="text-white/90">{message.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ROI Proof */}
      <section className="py-20 px-6 relative">
        <div className="mx-auto max-w-4xl text-center">
          <div className="relative p-12 rounded-2xl bg-gradient-to-br from-white/10 to-transparent border border-white/30 backdrop-blur-sm">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.1),transparent_70%)] rounded-2xl" />
            <div className="relative">
              <TrendingUp className="w-16 h-16 text-white mx-auto mb-6" />
              <blockquote className="text-2xl md:text-3xl font-bold text-white mb-4">
                "Businesses using eFreedom's AI book 20–40% more jobs."
              </blockquote>
              <p className="text-white/70 text-lg">
                Our AI receptionist captures leads your competitors miss, turning every call into a potential booking.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-gradient-to-t from-black to-transparent relative">
        <div className="mx-auto max-w-4xl text-center">
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-6">Ready to Stop Missing Calls?</h2>
          <p className="text-xl text-white/70 mb-8">
            Book a free call to see how our AI receptionist can transform your business.
          </p>
          <a
            href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)] text-lg"
          >
            Book a Free Call to See How It Works
          </a>
        </div>
      </section>
    </main>
  )
}
