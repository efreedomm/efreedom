import type { Metadata } from "next"
import { PricingSection } from "@/components/pricing-section"

export const metadata: Metadata = {
  title: "Pricing | Marketing Packages | eFreedom",
  description:
    "Affordable marketing packages designed for growing businesses. Get AI-powered lead generation, CRM automation, and digital marketing that drives real results.",
}

export default function PricingPage() {
  return (
    <main className="min-h-screen bg-[#0B121D] pt-16 opacity-100 text-background bg-background">
      <PricingSection />
    </main>
  )
}
