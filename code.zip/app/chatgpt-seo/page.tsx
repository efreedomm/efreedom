import type { Metadata } from "next"
import { ChatGPTSEOClient } from "./_components/ChatGPTSEOClient"

export const metadata: Metadata = {
  title: "ChatGPT SEO (GEO) - Get Found on AI Search | eFreedom",
  description:
    "Optimize your business for ChatGPT, Perplexity, and AI search engines. Get discovered when customers ask AI for recommendations. The future of SEO is here.",
  keywords: [
    "ChatGPT SEO",
    "GEO optimization",
    "AI search optimization",
    "generative engine optimization",
    "ChatGPT business listings",
    "AI search visibility",
  ],
}

export default function ChatGPTSEOPage() {
  return <ChatGPTSEOClient />
}
