"use client"

import { Database, TrendingUp, CheckCircle, AlertCircle, Users, BarChart3 } from "lucide-react"
import Image from "next/image"

export default function CRMPipelineClientPage() {
  return (
    <main className="bg-black relative">
      <div className="fixed inset-0 pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full opacity-30"
            style={{
              left: `${Math.random() * 100}%`,
              bottom: `-${Math.random() * 20}%`,
              animation: `float ${5 + Math.random() * 10}s linear infinite`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
      </div>
      <style jsx>{`
        @keyframes float {
          to {
            transform: translateY(-100vh);
            opacity: 0;
          }
        }
      `}</style>

      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden pt-24 pb-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.05),transparent_70%)]" />

        <div className="relative mx-auto max-w-5xl px-6 text-center">
          <h1 className="font-heading text-5xl md:text-7xl font-bold text-white mb-6">
            Stop Losing Leads in Spreadsheets
          </h1>
          <p className="text-xl md:text-2xl text-white/80 mb-8 max-w-3xl mx-auto text-balance">
            One unified CRM that tracks every lead from first contact to close. See your entire pipeline, revenue, and
            conversion rates in real-time.
          </p>
          <a
            href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)]"
          >
            <Database className="w-5 h-5" />
            See Your Dashboard
          </a>
        </div>
      </section>

      {/* The Problem */}
      <section className="py-20 px-6 relative">
        <div className="mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">The Problem</h2>
            <p className="text-xl text-white/70">Scattered data means lost revenue</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: AlertCircle,
                title: "Data Everywhere",
                description:
                  "Leads in your phone, notes in spreadsheets, appointments in your calendar. Nothing syncs.",
              },
              {
                icon: Users,
                title: "Lost Follow-Ups",
                description: "You forget to follow up with hot leads because there's no system tracking them.",
              },
              {
                icon: BarChart3,
                title: "No Visibility",
                description:
                  "You have no idea how many leads you have, where they are in your pipeline, or what's closing.",
              },
            ].map((problem, index) => (
              <div
                key={index}
                className="relative p-6 rounded-xl bg-gradient-to-br from-red-900/20 to-red-950/10 border border-red-500/20 backdrop-blur-sm"
              >
                <problem.icon className="w-12 h-12 text-red-400 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">{problem.title}</h3>
                <p className="text-white/70">{problem.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* The Fix */}
      <section className="py-20 px-6 bg-gradient-to-b from-transparent to-black/50 relative">
        <div className="mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">The Fix</h2>
            <p className="text-xl text-white">One system. All your data. Complete visibility.</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              {[
                {
                  step: "1",
                  title: "Unified Data Hub",
                  description: "Every lead, call, text, email, and appointment in one place. No more scattered info.",
                },
                {
                  step: "2",
                  title: "Automatic Tracking",
                  description: "System captures and organizes every interaction automatically. Zero manual data entry.",
                },
                {
                  step: "3",
                  title: "Pipeline Visibility",
                  description: "See exactly where every lead is: new, contacted, quoted, won, or lost.",
                },
                {
                  step: "4",
                  title: "Revenue Insights",
                  description: "Track conversion rates, revenue growth, and top opportunities in real-time.",
                },
              ].map((fix) => (
                <div
                  key={fix.step}
                  className="flex gap-4 p-6 rounded-xl bg-gradient-to-br from-white/10 to-transparent border border-white/20 backdrop-blur-sm"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-white text-black font-bold text-xl flex items-center justify-center">
                    {fix.step}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">{fix.title}</h3>
                    <p className="text-white/70">{fix.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-center">
              <div className="relative w-full">
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent rounded-2xl blur-3xl" />
                <div className="relative bg-black/80 backdrop-blur-md border border-white/30 rounded-2xl p-4 shadow-2xl">
                  <Image
                    src="/images/design-mode/image.png"
                    alt="CRM Dashboard showing revenue growth, conversion rates, and pipeline opportunities"
                    width={800}
                    height={600}
                    className="rounded-lg w-full h-auto"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* The Result */}
      <section className="py-20 px-6 relative">
        <div className="mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">The Result</h2>
            <p className="text-xl text-white/70">More closed deals, zero lost leads, complete control</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: CheckCircle,
                title: "Higher Close Rate",
                stat: "+28%",
                description: "Average increase in lead-to-customer conversion",
              },
              {
                icon: Users,
                title: "Zero Lost Leads",
                stat: "100%",
                description: "Every lead tracked and followed up automatically",
              },
              {
                icon: TrendingUp,
                title: "Revenue Growth",
                stat: "$18K+/mo",
                description: "Average additional revenue from better tracking",
              },
            ].map((result, index) => (
              <div
                key={index}
                className="relative p-8 rounded-xl bg-gradient-to-br from-white/10 to-transparent border border-white/20 backdrop-blur-sm text-center"
              >
                <result.icon className="w-12 h-12 text-white mx-auto mb-4" />
                <div className="text-4xl font-bold text-white mb-2">{result.stat}</div>
                <h3 className="text-xl font-bold text-white mb-2">{result.title}</h3>
                <p className="text-white/70 text-sm">{result.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Deep Dive */}
      <section className="py-20 px-6 bg-gradient-to-b from-black/50 to-transparent relative">
        <div className="mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">What You Get</h2>
            <p className="text-xl text-white/70">Everything you need to manage your pipeline</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {[
              {
                title: "Contact Management",
                description: "Store unlimited contacts with full history, notes, tags, and custom fields.",
              },
              {
                title: "Pipeline Stages",
                description: "Customize your sales stages and drag-and-drop leads through your process.",
              },
              {
                title: "Activity Timeline",
                description: "See every call, text, email, and appointment for each lead in chronological order.",
              },
              {
                title: "Revenue Forecasting",
                description: "Predict monthly revenue based on your pipeline and historical close rates.",
              },
              {
                title: "Team Collaboration",
                description: "Share leads, assign tasks, and keep your whole team on the same page.",
              },
              {
                title: "Mobile Access",
                description: "Update leads, check pipeline, and close deals from anywhere on your phone.",
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="p-6 rounded-xl bg-gradient-to-br from-white/10 to-transparent border border-white/20 backdrop-blur-sm"
              >
                <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                <p className="text-white/70">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ROI Proof */}
      <section className="py-20 px-6 relative">
        <div className="mx-auto max-w-4xl text-center">
          <div className="relative p-12 rounded-2xl bg-gradient-to-br from-white/10 to-transparent border border-white/30 backdrop-blur-sm">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.1),transparent_70%)] rounded-2xl" />
            <div className="relative">
              <TrendingUp className="w-16 h-16 text-white mx-auto mb-6" />
              <blockquote className="text-2xl md:text-3xl font-bold text-white mb-4">
                "Businesses using eFreedom's CRM close 25–35% more deals."
              </blockquote>
              <p className="text-white/70 text-lg">
                When you can see your entire pipeline and never miss a follow-up, your close rate skyrockets.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-gradient-to-t from-black to-transparent relative">
        <div className="mx-auto max-w-4xl text-center">
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to See Your Full Pipeline?
          </h2>
          <p className="text-xl text-white/70 mb-8">
            Book a free call to see how our CRM can transform your lead tracking and revenue growth.
          </p>
          <a
            href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)] text-lg"
          >
            Book a Free Call to See Your Dashboard
          </a>
        </div>
      </section>
    </main>
  )
}
