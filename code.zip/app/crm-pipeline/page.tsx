import type { Metadata } from "next"
import CRMPipelineClientPage from "./crm-pipeline-client"

export const metadata: Metadata = {
  title: "CRM + Pipeline Systems | Unified Revenue Tracking | eFreedom",
  description:
    "Stop losing leads in spreadsheets. eFreedom's CRM unifies your data, tracks every lead from first contact to close, and gives you complete pipeline visibility.",
  keywords: [
    "CRM system",
    "pipeline management",
    "lead tracking",
    "sales pipeline",
    "revenue tracking",
    "unified CRM",
    "business management software",
  ],
}

export default function CRMPipelinePage() {
  return <CRMPipelineClientPage />
}
