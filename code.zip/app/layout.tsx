import type React from "react"
import type { Metadata } from "next"
import Script from "next/script"

import { Analytics } from "@vercel/analytics/next"
import { SpeedInsights } from "@vercel/speed-insights/next"
import { Suspense } from "react"
import "./globals.css"

import { AIChatbot } from "@/components/ai-chatbot"
import { Header } from "@/components/header"

import { Bebas_Neue, Inter } from "next/font/google"

// Initialize fonts
const bebasNeue = Bebas_Neue({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-bebas",
  display: "swap",
})

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
})

export const metadata: Metadata = {
  title: "eFreedom | AI-Powered Business Growth",
  description: "Transform your business with AI-powered consulting solutions",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${bebasNeue.variable} ${inter.variable}`}>
      <head>
        <Script id="suppress-resize-observer-error" strategy="beforeInteractive">
          {`
            window.addEventListener('error', function(e) {
              if (e.message && e.message.includes('ResizeObserver loop')) {
                e.stopImmediatePropagation();
                e.preventDefault();
              }
            });
          `}
        </Script>
        <Script async src="https://www.googletagmanager.com/gtag/js?id=AW-17620968131" strategy="afterInteractive" />
        <Script id="google-ads-init" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'AW-17620968131');
          `}
        </Script>
        <Script id="google-ads-conversion" strategy="afterInteractive">
          {`
            function gtag_report_conversion(url) {
              var callback = function () {
                if (typeof(url) != 'undefined') {
                  window.location = url;
                }
              };
              gtag('event', 'conversion', {
                'send_to': 'AW-17620968131/_QUxCPaHqKYbEMPFqtJB',
                'value': 1.0,
                'currency': 'USD',
                'event_callback': callback
              });
              return false;
            }
          `}
        </Script>
      </head>
      <body className="font-sans antialiased">
        <Suspense fallback={<div>Loading...</div>}>
          <Header />
          {children}
          <Analytics />
          <SpeedInsights />
          <AIChatbot />
        </Suspense>
      </body>
    </html>
  )
}
