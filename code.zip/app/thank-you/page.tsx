import type { Metadata } from "next"
import Link from "next/link"
import { CheckCircle, ArrowRight } from "lucide-react"
import Script from "next/script"

export const metadata: Metadata = {
  title: "Thank You - StrivePoint Consulting",
  description: "Your consultation has been scheduled successfully.",
}

export default function ThankYouPage() {
  return (
    <>
      {/* Google Ads Conversion Tracking */}
      <Script
        id="google-ads-conversion"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
            gtag('event', 'conversion', {
              'send_to': 'AW-17620968131/_QUxCPaHqKYbEMPFqtJB',
              'value': 1.0,
              'currency': 'USD'
            });
          `,
        }}
      />

      <main className="min-h-screen bg-[#0B121D] flex items-center justify-center px-4">
        <div className="max-w-2xl w-full text-center">
          {/* Success Icon */}
          <div className="mb-8 inline-flex">
            <div className="relative">
              <div className="absolute inset-0 bg-[#C6A564]/20 blur-2xl rounded-full" />
              <CheckCircle className="relative h-24 w-24 text-[#C6A564]" />
            </div>
          </div>

          {/* Heading */}
          <h1 className="font-display text-5xl md:text-6xl font-bold text-white mb-6">You're All Set!</h1>

          {/* Message */}
          <p className="text-xl text-white/70 mb-4 leading-relaxed">
            Your strategy call has been scheduled successfully.
          </p>
          <p className="text-lg text-white/60 mb-12 leading-relaxed">
            Check your email for confirmation details and calendar invite. We're excited to help you build your revenue
            OS.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#C6A564] text-[#0B121D] font-semibold rounded-lg hover:bg-[#C6A564]/90 transition-all"
            >
              Back to Home
              <ArrowRight className="h-5 w-5" />
            </Link>
          </div>

          {/* Additional Info */}
          <div className="mt-16 p-6 bg-white/5 border border-white/10 rounded-xl">
            <h2 className="font-display text-xl font-bold text-white mb-3">What Happens Next?</h2>
            <ul className="text-left text-white/70 space-y-2">
              <li className="flex items-start gap-3">
                <span className="text-[#C6A564] mt-1">•</span>
                <span>You'll receive a confirmation email with your meeting details</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-[#C6A564] mt-1">•</span>
                <span>A calendar invite will be sent to ensure you don't miss the call</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-[#C6A564] mt-1">•</span>
                <span>Our team will prepare a custom growth strategy for your business</span>
              </li>
            </ul>
          </div>
        </div>
      </main>
    </>
  )
}
