"use client"

import { Search, Cog, Zap, Rocket, TrendingUp, CheckCircle2, Clock, Target, Shield } from "lucide-react"

const processSteps = [
  {
    icon: Search,
    number: "01",
    title: "We Learn Your Business",
    description:
      "We look at how you get customers now, spot the holes, and build a simple plan that guarantees more booked jobs.",
    details: ["Deep dive into your current marketing", "Identify missed opportunities", "Create custom growth roadmap"],
  },
  {
    icon: Cog,
    number: "02",
    title: "We Build Your System",
    description:
      "We set up your CRM, automations, emails, texts, and tracking. Everything connects so leads never slip through.",
    details: ["CRM & pipeline configuration", "Automated follow-up sequences", "Integration with your tools"],
  },
  {
    icon: Zap,
    number: "03",
    title: "We Turn It On",
    description:
      "Your system goes live. AI follows up, books calls, and keeps your pipeline full while we monitor everything.",
    details: ["24/7 AI assistant activation", "Real-time lead tracking", "Continuous monitoring"],
  },
  {
    icon: Rocket,
    number: "04",
    title: "We Scale the Results",
    description:
      "Once the foundation works, we add ads, SEO, and reviews to multiply your calls and revenue month after month.",
    details: ["Strategic ad campaigns", "SEO & GEO optimization", "Review generation system"],
  },
  {
    icon: TrendingUp,
    number: "05",
    title: "We Guarantee It Works",
    description:
      "We track booked jobs and revenue—not clicks. If your results aren't there by month 2, we work free until they are.",
    details: ["Performance dashboard access", "Weekly progress reports", "Results-based guarantee"],
  },
]

const whyDifferent = [
  {
    icon: Target,
    title: "Results, Not Vanity Metrics",
    description: "We measure booked jobs and revenue—not likes, clicks, or impressions.",
  },
  {
    icon: Clock,
    title: "24/7 Automation",
    description:
      "Your system never sleeps. AI handles follow-ups, bookings, and customer communication around the clock.",
  },
  {
    icon: Shield,
    title: "Risk-Free Guarantee",
    description: "No results by month 2? We work for free until you get them. Your success is our success.",
  },
  {
    icon: CheckCircle2,
    title: "Done-For-You Service",
    description: "We build it, launch it, and manage it. You focus on running your business while we grow it.",
  },
]

export default function HowItWorksPage() {
  return (
    <main className="min-h-screen bg-black pt-16">
      {/* Particles Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full animate-particle-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${3 + Math.random() * 4}s`,
              opacity: 0.3,
            }}
          />
        ))}
      </div>

      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.05),transparent_70%)]" />

        <div className="relative max-w-5xl mx-auto text-center">
          <h1 className="font-display font-black text-5xl md:text-7xl text-white mb-6">
            How <span className="text-white">eFreedom</span> Works
          </h1>
          <p className="text-xl md:text-2xl text-white/70 max-w-3xl mx-auto leading-relaxed">
            We turn missed calls into booked jobs with automation that never sleeps. Here's exactly how we do it.
          </p>
        </div>
      </section>

      {/* Process Steps */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-display font-bold text-4xl md:text-5xl text-white mb-4">Our 5-Step Process</h2>
            <p className="text-lg text-white/60">From discovery to domination—here's how we grow your business</p>
          </div>

          <div className="space-y-8">
            {processSteps.map((step, index) => (
              <div
                key={index}
                className="group relative bg-gradient-to-br from-zinc-900 to-black border border-white/20 rounded-2xl p-8 hover:border-white/40 transition-all duration-300 hover:shadow-[0_0_40px_rgba(255,255,255,0.1)]"
              >
                <div className="flex flex-col md:flex-row gap-6">
                  {/* Number & Icon */}
                  <div className="flex items-center gap-4 md:flex-col md:items-start">
                    <div className="text-6xl font-display font-black text-white/10">{step.number}</div>
                    <div className="p-4 bg-white/10 rounded-xl">
                      <step.icon className="w-8 h-8 text-white" />
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <h3 className="font-display font-bold text-2xl md:text-3xl text-white mb-3">{step.title}</h3>
                    <p className="text-white/70 text-lg mb-4 leading-relaxed">{step.description}</p>
                    <ul className="space-y-2">
                      {step.details.map((detail, idx) => (
                        <li key={idx} className="flex items-center gap-2 text-white/60">
                          <CheckCircle2 className="w-4 h-4 text-white flex-shrink-0" />
                          <span>{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Hover glow */}
                <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-white/5 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why We're Different */}
      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:100px_100px]" />

        <div className="relative max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-display font-bold text-4xl md:text-5xl text-white mb-4">Why eFreedom Is Different</h2>
            <p className="text-lg text-white/60">We're not another marketing agency—we're your growth partner</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {whyDifferent.map((item, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-zinc-900/80 to-black/80 border border-white/20 rounded-2xl p-8 hover:border-white/40 transition-all duration-300"
              >
                <div className="p-3 bg-white/10 rounded-xl w-fit mb-4">
                  <item.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-display font-bold text-xl text-white mb-3">{item.title}</h3>
                <p className="text-white/70 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-br from-zinc-900 to-black border-2 border-white rounded-3xl p-12">
            <h2 className="font-display font-bold text-3xl md:text-4xl text-white mb-4">
              Ready to See How It Works for Your Business?
            </h2>
            <p className="text-lg text-white/70 mb-8">
              Book a free strategy call and we'll show you exactly how eFreedom can grow your business.
            </p>
            <a
              href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-black font-display font-bold text-lg px-8 py-4 rounded-xl hover:shadow-[0_0_30px_rgba(255,255,255,0.5)] transition-all duration-300"
            >
              Book Your Free Strategy Call
            </a>
          </div>
        </div>
      </section>

      {/* CSS Animation */}
      <style jsx>{`
        @keyframes particle-float {
          0% {
            transform: translateY(0) translateX(0);
            opacity: 0;
          }
          10% {
            opacity: 0.3;
          }
          90% {
            opacity: 0.1;
          }
          100% {
            transform: translateY(-100vh) translateX(${Math.random() * 100 - 50}px);
            opacity: 0;
          }
        }
        .animate-particle-float {
          animation: particle-float linear infinite;
        }
      `}</style>
    </main>
  )
}
