"use client"

import { motion } from "framer-motion"
import { ArrowRight, Zap, MessageSquare, Target, TrendingUp, CheckCircle2, BarChart3 } from "lucide-react"
import { useState, useEffect } from "react"

export function WebsiteDevelopmentClient() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const beforeMetrics = [
    { label: "Page Load Time", value: "8.2s", color: "text-red-400" },
    { label: "Monthly Visitors", value: "450", color: "text-red-400" },
    { label: "Form Submissions", value: "12", color: "text-red-400" },
    { label: "Phone Calls", value: "8", color: "text-red-400" },
    { label: "Conversion Rate", value: "2.1%", color: "text-red-400" },
  ]

  const afterMetrics = [
    { label: "Page Load Time", value: "1.4s", color: "text-white" },
    { label: "Monthly Visitors", value: "1,240", color: "text-white" },
    { label: "Form Submissions", value: "48", color: "text-white" },
    { label: "Phone Calls", value: "32", color: "text-white" },
    { label: "Conversion Rate", value: "6.5%", color: "text-white" },
  ]

  const features = [
    {
      icon: Zap,
      title: "Lightning Fast Loading",
      description: "Optimized code and images load in under 2 seconds — Google loves it, customers stay.",
    },
    {
      icon: MessageSquare,
      title: "AI Chat Widget",
      description: "Instant answers to visitor questions 24/7, capturing leads even when you're busy.",
    },
    {
      icon: Target,
      title: "Conversion-Focused Design",
      description: "Every button, form, and CTA is designed to turn visitors into booked jobs.",
    },
    {
      icon: BarChart3,
      title: "Full Lead Tracking",
      description: "Pixel tracking shows exactly where every lead came from — no more guessing.",
    },
  ]

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {Array.from({ length: 20 }).map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 bg-white/20 rounded-full animate-float"
          style={{
            left: `${Math.random() * 100}%`,
            bottom: `-${Math.random() * 20}px`,
            animationDelay: `${Math.random() * 5}s`,
            animationDuration: `${15 + Math.random() * 10}s`,
          }}
        />
      ))}

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-black to-black/90 pt-32 pb-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.03),transparent_70%)]" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 text-balance">
              Turn Your Website Into a <span className="text-white">Job Machine</span>
            </h1>
            <p className="text-xl md:text-2xl text-white/80 mb-8 max-w-3xl mx-auto text-balance">
              We rebuild your site to load fast, convert visitors, and track every lead that comes in.
            </p>
            <a
              href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)]"
            >
              See 90-Second Demo
              <ArrowRight className="w-5 h-5" />
            </a>
          </motion.div>
        </div>
      </section>

      {/* The Problem */}
      <section className="py-20 bg-black">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">The Problem</h2>
            <p className="text-xl text-red-400 font-semibold mb-4">
              "Your site's just a brochure — no tracking, no conversions."
            </p>
            <p className="text-lg text-white/70 max-w-3xl mx-auto text-balance">
              Most business websites are slow, outdated, and don't capture leads. Visitors leave without calling, and
              you have no idea where your traffic comes from or why they didn't convert.
            </p>
          </motion.div>
        </div>
      </section>

      {/* The Fix */}
      <section className="py-20 bg-gradient-to-b from-black to-black/90">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">The Fix</h2>
            <p className="text-xl text-white font-semibold mb-4">AI chat + instant text back + pixel tracking</p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-black/50 backdrop-blur-sm border border-white/20 rounded-xl p-8 hover:border-white/40 transition-all duration-300"
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-white/10 rounded-lg">
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
                      <p className="text-white/70">{feature.description}</p>
                    </div>
                  </div>
                </motion.div>
              )
            })}
          </div>
        </div>
      </section>

      {/* The Result */}
      <section className="py-20 bg-black">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">The Result</h2>
            <p className="text-xl text-white font-semibold mb-8">3x more calls and form submissions</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: CheckCircle2, stat: "3x", label: "More Leads" },
              { icon: TrendingUp, stat: "78%", label: "Faster Load Time" },
              { icon: Target, stat: "7.5%", label: "Conversion Rate" },
            ].map((item, index) => {
              const Icon = item.icon
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-gradient-to-br from-white/10 to-transparent border border-white/20 rounded-xl p-8 text-center"
                >
                  <Icon className="w-12 h-12 text-white mx-auto mb-4" />
                  <div className="text-5xl font-bold text-white mb-2">{item.stat}</div>
                  <div className="text-white/70">{item.label}</div>
                </motion.div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Before/After Analytics */}
      <section className="py-20 bg-gradient-to-b from-black to-black/90">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Proof: Real Analytics</h2>
            <p className="text-xl text-white/70 max-w-3xl mx-auto text-balance">
              Here's what happens when we rebuild a business website with conversion tracking and optimization.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Before */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-black/50 backdrop-blur-sm border border-red-500/20 rounded-xl p-8"
            >
              <h3 className="text-2xl font-bold text-red-400 mb-6 text-center">Before eFreedom</h3>
              <div className="space-y-4">
                {beforeMetrics.map((metric, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="flex justify-between items-center p-4 bg-red-500/5 rounded-lg"
                  >
                    <span className="text-white/70">{metric.label}</span>
                    <span className={`text-2xl font-bold ${metric.color}`}>{metric.value}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* After */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-black/50 backdrop-blur-sm border border-white/20 rounded-xl p-8"
            >
              <h3 className="text-2xl font-bold text-white mb-6 text-center">After eFreedom</h3>
              <div className="space-y-4">
                {afterMetrics.map((metric, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: 10 }}
                    whileInView={{ opacity: isVisible ? 1 : 0, x: isVisible ? 0 : 10 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
                    className="flex justify-between items-center p-4 bg-white/5 rounded-lg"
                  >
                    <span className="text-white/70">{metric.label}</span>
                    <span className={`text-2xl font-bold ${metric.color}`}>{metric.value}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-black">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Ready to Rebuild Your Site?</h2>
            <p className="text-xl text-white/70 mb-8 text-balance">
              Let's turn your website into a lead-generating machine that works 24/7.
            </p>
            <a
              href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)]"
            >
              Rebuild My Site
              <ArrowRight className="w-5 h-5" />
            </a>
          </motion.div>
        </div>
      </section>

      <style jsx>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0) translateX(0);
            opacity: 0;
          }
          10% {
            opacity: 0.2;
          }
          90% {
            opacity: 0.2;
          }
          100% {
            transform: translateY(-100vh) translateX(${Math.random() * 100 - 50}px);
            opacity: 0;
          }
        }
        .animate-float {
          animation: float linear infinite;
        }
      `}</style>
    </div>
  )
}
