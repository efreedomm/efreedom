import type { Metadata } from "next"
import { WebsiteDevelopmentClient } from "./_components/WebsiteDevelopmentClient"

export const metadata: Metadata = {
  title: "Website Development for Businesses | eFreedom",
  description:
    "Turn your website into a job machine. We rebuild business websites to load fast, convert visitors, and track every lead. AI chat, instant text back, and pixel tracking included.",
  keywords: [
    "website design",
    "website rebuild",
    "conversion website builders",
    "web development",
    "business websites",
    "lead tracking websites",
  ],
}

export default function WebsiteDevelopmentPage() {
  return <WebsiteDevelopmentClient />
}
