"use client"

import { Search, MapPin, Star, TrendingUp, CheckCircle2, ArrowRight } from "lucide-react"

export default function LocalSEOClientPage() {
  return (
    <main className="min-h-screen bg-black relative">
      <div className="fixed inset-0 pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full opacity-30"
            style={{
              left: `${Math.random() * 100}%`,
              bottom: `-${Math.random() * 20}%`,
              animation: `float ${5 + Math.random() * 10}s linear infinite`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
      </div>
      <style jsx>{`
        @keyframes float {
          to {
            transform: translateY(-100vh);
            opacity: 0;
          }
        }
      `}</style>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-black to-black/90 pt-32 pb-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.05),transparent_70%)]" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 text-balance">
              Get Found. <span className="text-white">Get Booked.</span>
            </h1>
            <p className="text-xl md:text-2xl text-white/80 mb-8 text-balance">
              We rank your business on Google Maps and local search so customers find YOU first.
            </p>
            <a
              href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)]"
            >
              Claim My Local SEO Audit
              <ArrowRight className="w-5 h-5" />
            </a>
          </div>
        </div>
      </section>

      {/* The Problem */}
      <section className="py-20 bg-black relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-500/10 mb-6">
              <Search className="w-8 h-8 text-red-500" />
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">The Problem</h2>
            <p className="text-xl text-white/80 mb-8 text-balance">"Competitors always show up first."</p>
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-8">
              <ul className="space-y-4 text-left text-white/70">
                <li className="flex items-start gap-3">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>Your business doesn't show up in the Google Map Pack</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>Competitors with worse service rank higher than you</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>Customers can't find you when they search for your services</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-500 mt-1">✗</span>
                  <span>You're losing jobs to businesses that just have better SEO</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* The Fix */}
      <section className="py-20 bg-gradient-to-b from-black to-black/90 relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/10 mb-6">
              <MapPin className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">The Fix</h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto text-balance">
              Optimized Google Business, citations, and keywords that get you found.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl p-8">
              <div className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center mb-4">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Google Business Optimization</h3>
              <p className="text-white/70">
                We fully optimize your Google Business Profile with the right categories, photos, posts, and keywords to
                rank in the Map Pack.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl p-8">
              <div className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center mb-4">
                <Search className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Local Citations & Listings</h3>
              <p className="text-white/70">
                We build and manage citations across 50+ directories to boost your local authority and help Google trust
                your business.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl p-8">
              <div className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center mb-4">
                <Star className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Review Generation</h3>
              <p className="text-white/70">
                More 5-star reviews = higher rankings. We automate review requests so you consistently get more positive
                reviews than competitors.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* The Result */}
      <section className="py-20 bg-black relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/10 mb-6">
              <TrendingUp className="w-8 h-8 text-green-500" />
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">The Result</h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto text-balance">More calls, more reviews, more jobs.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">3-5x</div>
              <div className="text-white/70">More Google visibility</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">40%+</div>
              <div className="text-white/70">Increase in calls</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">Top 3</div>
              <div className="text-white/70">Map Pack ranking</div>
            </div>
          </div>

          <div className="mt-12 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl p-8 max-w-3xl mx-auto">
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Show up in the Google Map Pack for your service area</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Get more calls from customers searching for your services</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Build a steady stream of 5-star reviews</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Outrank competitors in your local market</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Proof - Map Pack Visual */}
      <section className="py-20 bg-gradient-to-b from-black to-black/90 relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Real Results</h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto text-balance">
              See how we help contractors dominate local search and the Google Map Pack.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Before */}
            <div className="bg-white/5 backdrop-blur-sm border border-red-500/20 rounded-xl p-8">
              <div className="text-center mb-6">
                <span className="inline-block px-4 py-2 bg-red-500/10 text-red-500 rounded-full text-sm font-semibold">
                  BEFORE
                </span>
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-black/50 rounded-lg">
                  <span className="text-white/70">Map Pack Ranking</span>
                  <span className="text-red-500 font-bold">Not visible</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-black/50 rounded-lg">
                  <span className="text-white/70">Google Reviews</span>
                  <span className="text-red-500 font-bold">12 reviews</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-black/50 rounded-lg">
                  <span className="text-white/70">Monthly Calls</span>
                  <span className="text-red-500 font-bold">15-20</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-black/50 rounded-lg">
                  <span className="text-white/70">Search Visibility</span>
                  <span className="text-red-500 font-bold">Page 2-3</span>
                </div>
              </div>
            </div>

            {/* After */}
            <div className="bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl p-8">
              <div className="text-center mb-6">
                <span className="inline-block px-4 py-2 bg-white/10 text-white rounded-full text-sm font-semibold">
                  AFTER 90 DAYS
                </span>
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-black/50 rounded-lg">
                  <span className="text-white/70">Map Pack Ranking</span>
                  <span className="text-white font-bold">#2 Position</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-black/50 rounded-lg">
                  <span className="text-white/70">Google Reviews</span>
                  <span className="text-white font-bold">47 reviews</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-black/50 rounded-lg">
                  <span className="text-white/70">Monthly Calls</span>
                  <span className="text-white font-bold">60-75</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-black/50 rounded-lg">
                  <span className="text-white/70">Search Visibility</span>
                  <span className="text-white font-bold">Top 3</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-black relative">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 text-balance">
            Ready to Dominate Local Search?
          </h2>
          <p className="text-xl text-white/80 mb-8 text-balance">
            Get a free local SEO audit and see exactly where you're losing customers to competitors.
          </p>
          <a
            href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)]"
          >
            Claim My Local SEO Audit
            <ArrowRight className="w-5 h-5" />
          </a>
        </div>
      </section>
    </main>
  )
}
