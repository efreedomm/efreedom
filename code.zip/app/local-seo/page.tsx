import type { Metadata } from "next"
import LocalSEOClientPage from "./local-seo-client"

export const metadata: Metadata = {
  title: "Local SEO | Google Business Optimization | eFreedom",
  description:
    "Rank higher on Google Maps and local search. Local SEO services, Google Business optimization, and strategies to get found by customers first.",
  keywords: [
    "local SEO",
    "Google Business optimization",
    "rank higher on Google Maps",
    "local search optimization",
    "Google Business Profile",
    "local SEO services",
  ],
}

export default function LocalSEOPage() {
  return <LocalSEOClientPage />
}
