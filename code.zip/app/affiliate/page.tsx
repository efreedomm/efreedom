import { AffiliateHero } from "@/components/affiliate-hero"
import { AffiliateProcess } from "@/components/affiliate-process"
import { AffiliateFAQ } from "@/components/affiliate-faq"
import { Footer } from "@/components/footer"

export default function AffiliatePage() {
  return (
    <main className="min-h-screen bg-navy">
      <AffiliateHero />
      <AffiliateProcess />
      <AffiliateFAQ />
      <Footer />
    </main>
  )
}
