import type { Metadata } from "next"
import DigitalAdsClientPage from "./digital-ads-client"

export const metadata: Metadata = {
  title: "Digital Ads & Funnels | eFreedom",
  description:
    "We run Meta & Google ads that actually track calls, forms, and booked appointments — not just clicks. Digital advertising that converts with full conversion tracking.",
  keywords: [
    "digital advertising",
    "conversion-focused ads",
    "sales funnel optimization",
    "Google ads management",
    "Meta ads management",
    "conversion tracking",
  ],
}

export default function DigitalAdsPage() {
  return <DigitalAdsClientPage />
}
