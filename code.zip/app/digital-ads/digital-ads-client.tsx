"use client"

import { TrendingUp, Target, Zap, CheckCircle2, ArrowRight } from "lucide-react"
import { DigitalAdsClient } from "./_components/DigitalAdsClient"

export default function DigitalAdsClientPage() {
  return (
    <main className="min-h-screen bg-black relative">
      <div className="fixed inset-0 pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full opacity-30"
            style={{
              left: `${Math.random() * 100}%`,
              bottom: `-${Math.random() * 20}%`,
              animation: `float ${5 + Math.random() * 10}s linear infinite`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
      </div>
      <style jsx>{`
        @keyframes float {
          to {
            transform: translateY(-100vh);
            opacity: 0;
          }
        }
      `}</style>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-black to-black/90 pt-32 pb-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.05),transparent_70%)]" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 text-balance">
              Ads That Turn Into <span className="text-white">Jobs</span>
            </h1>
            <p className="text-xl md:text-2xl text-white/80 max-w-3xl mx-auto mb-8 text-balance">
              We run Meta & Google ads that actually track calls, forms, and booked jobs — not just clicks.
            </p>
            <a
              href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)]"
            >
              Book a Strategy Call
              <ArrowRight className="w-5 h-5" />
            </a>
          </div>
        </div>
      </section>

      {/* The Problem */}
      <section className="py-20 bg-black relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="bg-gradient-to-br from-red-500/10 to-red-600/5 backdrop-blur-sm border border-red-500/20 rounded-2xl p-8 md:p-12">
              <div className="flex items-start gap-4 mb-6">
                <div className="p-3 bg-red-500/20 rounded-lg">
                  <Target className="w-8 h-8 text-red-400" />
                </div>
                <div>
                  <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">The Problem</h2>
                  <p className="text-xl text-red-200/90 font-semibold mb-4">"Ads eat money. No results."</p>
                </div>
              </div>
              <div className="space-y-4 text-white/80 text-lg">
                <p>You've tried running ads before. Maybe you're even running them now.</p>
                <p>But here's what happens:</p>
                <ul className="space-y-3 ml-6">
                  <li className="flex items-start gap-3">
                    <span className="text-red-400 mt-1">•</span>
                    <span>You spend $2,000/month and have no idea if it's working</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-red-400 mt-1">•</span>
                    <span>Clicks don't turn into calls. Calls don't turn into jobs.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-red-400 mt-1">•</span>
                    <span>Your "marketing guy" shows you impressions, not revenue</span>
                  </li>
                </ul>
                <p className="font-semibold text-red-200 pt-4">
                  Most contractors waste thousands on ads that don't track what actually matters: booked jobs.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* The Fix */}
      <section className="py-20 bg-gradient-to-b from-black to-black/90 relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm border border-white/20 rounded-2xl p-8 md:p-12">
              <div className="flex items-start gap-4 mb-6">
                <div className="p-3 bg-white/20 rounded-lg">
                  <Zap className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">The Fix</h2>
                  <p className="text-xl text-white font-semibold mb-4">
                    Conversion-focused funnels + CRM tracking + weekly optimization
                  </p>
                </div>
              </div>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <CheckCircle2 className="w-6 h-6 text-white flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">Landing Pages That Convert</h3>
                    <p className="text-white/70">
                      We build custom landing pages designed to turn clicks into calls and form fills — not just
                      traffic.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <CheckCircle2 className="w-6 h-6 text-white flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">Full CRM Integration</h3>
                    <p className="text-white/70">
                      Every lead is tracked from ad click → form fill → call → booked job. You see exactly what's
                      working.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <CheckCircle2 className="w-6 h-6 text-white flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">Weekly Optimization</h3>
                    <p className="text-white/70">
                      We test, tweak, and optimize every week to lower your cost per job and increase ROI.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <CheckCircle2 className="w-6 h-6 text-white flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">Meta & Google Ads</h3>
                    <p className="text-white/70">
                      We run campaigns on both platforms, targeting homeowners in your service area who need your
                      services now.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* The Result */}
      <section className="py-20 bg-black relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-gradient-to-br from-green-500/10 to-green-600/5 backdrop-blur-sm border border-green-500/20 rounded-2xl p-8 md:p-12">
              <div className="flex justify-center mb-6">
                <div className="p-4 bg-green-500/20 rounded-lg">
                  <TrendingUp className="w-12 h-12 text-green-400" />
                </div>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">The Result</h2>
              <p className="text-2xl text-green-300 font-semibold mb-6">Predictable new jobs every week</p>
              <div className="space-y-4 text-white/80 text-lg">
                <p>No more guessing. No more wasted ad spend.</p>
                <p>You get a dashboard that shows:</p>
                <ul className="space-y-3 inline-block text-left">
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                    <span>How many leads came in this week</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                    <span>How many turned into booked jobs</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                    <span>Your exact cost per job</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                    <span>Your ROI (revenue vs. ad spend)</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Proof - Before/After Data Visual */}
      <DigitalAdsClient />

      {/* Final CTA */}
      <section className="py-20 bg-black relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm border border-white/20 rounded-2xl p-12">
              <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Ready to Make Your Ads Pay Off?</h2>
              <p className="text-xl text-white/80 mb-8">
                Book a free strategy call and we'll show you exactly how we'd turn your ad spend into booked jobs.
              </p>
              <a
                href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)] text-lg"
              >
                Book a Strategy Call
                <ArrowRight className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
