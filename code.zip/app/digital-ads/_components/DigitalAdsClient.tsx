"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { TrendingUp, TrendingDown } from "lucide-react"

export function DigitalAdsClient() {
  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    // Start animation after component mounts
    const timer = setTimeout(() => setIsAnimating(true), 500)
    return () => clearTimeout(timer)
  }, [])

  const beforeData = {
    leads: 12,
    bookedJobs: 3,
    costPerJob: 667,
    roi: "1.2x",
  }

  const afterData = {
    leads: 48,
    bookedJobs: 18,
    costPerJob: 222,
    roi: "4.8x",
  }

  return (
    <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
      {/* Before */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6 }}
        className="bg-gradient-to-br from-red-500/10 to-red-600/5 backdrop-blur-sm border border-red-500/20 rounded-2xl p-8"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-red-500/20 rounded-lg">
            <TrendingDown className="w-6 h-6 text-red-400" />
          </div>
          <h3 className="text-2xl font-bold text-white">Before StrivePoint</h3>
        </div>

        <div className="space-y-6">
          <div>
            <div className="flex justify-between items-baseline mb-2">
              <span className="text-white/70">Monthly Leads</span>
              <motion.span
                className="text-3xl font-bold text-red-300"
                initial={{ scale: 0 }}
                animate={{ scale: isAnimating ? 1 : 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                {beforeData.leads}
              </motion.span>
            </div>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-red-400"
                initial={{ width: 0 }}
                animate={{ width: isAnimating ? "25%" : 0 }}
                transition={{ duration: 0.8, delay: 0.3 }}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-baseline mb-2">
              <span className="text-white/70">Booked Jobs</span>
              <motion.span
                className="text-3xl font-bold text-red-300"
                initial={{ scale: 0 }}
                animate={{ scale: isAnimating ? 1 : 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                {beforeData.bookedJobs}
              </motion.span>
            </div>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-red-400"
                initial={{ width: 0 }}
                animate={{ width: isAnimating ? "17%" : 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
              />
            </div>
          </div>

          <div className="pt-4 border-t border-white/10">
            <div className="flex justify-between items-baseline mb-1">
              
              
            </div>
            <div className="flex justify-between items-baseline">
              <span className="text-white/70">ROI</span>
              <span className="text-2xl font-bold text-red-300">{beforeData.roi}</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* After */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="bg-gradient-to-br from-[#C6A564]/10 to-[#C6A564]/5 backdrop-blur-sm border border-[#C6A564]/20 rounded-2xl p-8"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-[#C6A564]/20 rounded-lg">
            <TrendingUp className="w-6 h-6 text-[#C6A564]" />
          </div>
          <h3 className="text-2xl font-bold text-white">After StrivePoint</h3>
        </div>

        <div className="space-y-6">
          <div>
            <div className="flex justify-between items-baseline mb-2">
              <span className="text-white/70">Monthly Leads</span>
              <motion.span
                className="text-3xl font-bold text-[#C6A564]"
                initial={{ scale: 0 }}
                animate={{ scale: isAnimating ? 1 : 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                {afterData.leads}
              </motion.span>
            </div>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-[#C6A564]"
                initial={{ width: 0 }}
                animate={{ width: isAnimating ? "100%" : 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-baseline mb-2">
              <span className="text-white/70">Booked Jobs</span>
              <motion.span
                className="text-3xl font-bold text-[#C6A564]"
                initial={{ scale: 0 }}
                animate={{ scale: isAnimating ? 1 : 0 }}
                transition={{ duration: 0.5, delay: 0.6 }}
              >
                {afterData.bookedJobs}
              </motion.span>
            </div>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-[#C6A564]"
                initial={{ width: 0 }}
                animate={{ width: isAnimating ? "100%" : 0 }}
                transition={{ duration: 0.8, delay: 0.7 }}
              />
            </div>
          </div>

          <div className="pt-4 border-t border-white/10">
            <div className="flex justify-between items-baseline mb-1">
              
              
            </div>
            <div className="flex justify-between items-baseline">
              <span className="text-white/70">ROI</span>
              <span className="text-2xl font-bold text-[#C6A564]">{afterData.roi}</span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
