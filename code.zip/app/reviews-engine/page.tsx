import type { Metadata } from "next"
import { ReviewsEngineClient } from "./_components/ReviewsEngineClient"

export const metadata: Metadata = {
  title: "Reviews Engine - Automated Review Requests for Businesses | eFreedom",
  description:
    "Automate review requests after every job. Get more 5-star Google reviews, boost your reputation, and get more calls. Review automation for businesses.",
  keywords: [
    "review automation",
    "Google reviews",
    "review request text system",
    "automated review requests",
    "reputation management",
    "5-star review automation",
  ],
}

export default function ReviewsEnginePage() {
  return <ReviewsEngineClient />
}
