"use client"

import { motion } from "framer-motion"
import { Star, MessageSquare, TrendingUp, CheckCircle2, ArrowRight } from "lucide-react"
import { useState, useEffect } from "react"

export function ReviewsEngineClient() {
  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {Array.from({ length: 20 }).map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 bg-white/20 rounded-full animate-float"
          style={{
            left: `${Math.random() * 100}%`,
            bottom: `-${Math.random() * 20}px`,
            animationDelay: `${Math.random() * 5}s`,
            animationDuration: `${15 + Math.random() * 10}s`,
          }}
        />
      ))}

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-black to-black/90 pt-32 pb-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.03),transparent_70%)]" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 text-balance">More 5-Stars. More Jobs.</h1>
            <p className="text-xl md:text-2xl text-white/80 mb-8 max-w-3xl mx-auto text-balance">
              We automate review requests after every job so your phone rings more and your reputation grows.
            </p>
            <a
              href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)]"
            >
              See 90-sec Demo
              <ArrowRight className="w-5 h-5" />
            </a>
          </motion.div>
        </div>
      </section>

      {/* The Problem */}
      <section className="py-20 bg-black">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">The Problem</h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto text-balance">
              You do great work, but nobody leaves reviews. Your competitors with worse service outrank you because they
              have more 5-star ratings.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Star, title: "No Reviews", desc: "Customers forget to leave feedback" },
              { icon: TrendingUp, title: "Low Rankings", desc: "Competitors show up first on Google" },
              { icon: MessageSquare, title: "Lost Trust", desc: "New customers choose businesses with more reviews" },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="p-6 bg-red-500/10 border border-red-500/20 rounded-lg backdrop-blur-sm"
              >
                <item.icon className="w-12 h-12 text-red-400 mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">{item.title}</h3>
                <p className="text-white/70">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* The Fix */}
      <section className="py-20 bg-gradient-to-b from-black to-black/90">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">The Fix</h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto text-balance">
              eFreedom's Reviews Engine automatically sends review requests after every completed job — via text and
              email — so you get more 5-star ratings without lifting a finger.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: "Automated Review Texts",
                desc: "Send personalized review requests via SMS immediately after job completion",
              },
              {
                title: "Email Follow-Ups",
                desc: "Backup email requests with direct links to your Google Business profile",
              },
              {
                title: "Perfect Timing",
                desc: "Catch customers when they're happiest — right after you finish the job",
              },
              {
                title: "One-Click Reviews",
                desc: "Make it easy with direct links to leave a 5-star review in seconds",
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="p-6 bg-white/10 border border-white/20 rounded-lg backdrop-blur-sm"
              >
                <CheckCircle2 className="w-8 h-8 text-white mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">{item.title}</h3>
                <p className="text-white/70">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* The Result */}
      <section className="py-20 bg-black">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">The Result</h2>
            <p className="text-xl text-white/80 max-w-3xl mx-auto text-balance">
              More 5-star ratings → Higher Google rankings → More calls → More jobs
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { metric: "3-5x", label: "More Reviews Per Month" },
              { metric: "40%", label: "Higher Google Ranking" },
              { metric: "2x", label: "More Inbound Calls" },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="p-8 bg-gradient-to-br from-white/20 to-white/5 border border-white/30 rounded-lg backdrop-blur-sm text-center"
              >
                <div className="text-5xl font-bold text-white mb-2">{item.metric}</div>
                <div className="text-lg text-white/80">{item.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Proof - Before/After Graph */}
      <ReviewGrowthChart />

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-b from-black to-black/90">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Ready to Boost Your Reviews?</h2>
            <p className="text-xl text-white/80 mb-8 text-balance">
              Start getting more 5-star reviews automatically. Book a free strategy call to see how it works.
            </p>
            <a
              href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)] text-lg"
            >
              Boost My Reviews
              <ArrowRight className="w-5 h-5" />
            </a>
          </motion.div>
        </div>
      </section>

      <style jsx>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0) translateX(0);
            opacity: 0;
          }
          10% {
            opacity: 0.2;
          }
          90% {
            opacity: 0.2;
          }
          100% {
            transform: translateY(-100vh) translateX(${Math.random() * 100 - 50}px);
            opacity: 0;
          }
        }
        .animate-float {
          animation: float linear infinite;
        }
      `}</style>
    </div>
  )
}

function ReviewGrowthChart() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const beforeData = [2, 3, 2, 4, 3, 5]
  const afterData = [8, 12, 15, 18, 22, 25]
  const months = ["Month 1", "Month 2", "Month 3", "Month 4", "Month 5", "Month 6"]

  return (
    <section className="py-20 bg-gradient-to-b from-black/90 to-black">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Proof: Real Review Growth</h2>
          <p className="text-xl text-white/80 max-w-3xl mx-auto">
            See how automated review requests transform your Google Business profile
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Before */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="p-8 bg-red-500/10 border border-red-500/20 rounded-lg backdrop-blur-sm"
          >
            <h3 className="text-2xl font-bold text-white mb-6 text-center">Before: Manual Requests</h3>
            <div className="space-y-4">
              {months.map((month, index) => (
                <div key={month} className="flex items-center gap-4">
                  <div className="w-24 text-white/70 text-sm">{month}</div>
                  <div className="flex-1 bg-black/50 rounded-full h-8 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={isVisible ? { width: `${(beforeData[index] / 25) * 100}%` } : { width: 0 }}
                      transition={{ duration: 1, delay: index * 0.1 }}
                      className="h-full bg-red-500/50 flex items-center justify-end pr-2"
                    >
                      <span className="text-white text-sm font-semibold">{beforeData[index]}</span>
                    </motion.div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 text-center">
              <div className="text-3xl font-bold text-red-400">18 reviews</div>
              <div className="text-white/60">Total in 6 months</div>
            </div>
          </motion.div>

          {/* After */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="p-8 bg-white/10 border border-white/20 rounded-lg backdrop-blur-sm"
          >
            <h3 className="text-2xl font-bold text-white mb-6 text-center">After: Automated System</h3>
            <div className="space-y-4">
              {months.map((month, index) => (
                <div key={month} className="flex items-center gap-4">
                  <div className="w-24 text-white/70 text-sm">{month}</div>
                  <div className="flex-1 bg-black/50 rounded-full h-8 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={isVisible ? { width: `${(afterData[index] / 25) * 100}%` } : { width: 0 }}
                      transition={{ duration: 1, delay: index * 0.1 }}
                      className="h-full bg-white flex items-center justify-end pr-2"
                    >
                      <span className="text-black text-sm font-semibold">{afterData[index]}</span>
                    </motion.div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 text-center">
              <div className="text-3xl font-bold text-white">100 reviews</div>
              <div className="text-white/60">Total in 6 months</div>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-12 text-center"
        >
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-white/20 border border-white/30 rounded-lg">
            <TrendingUp className="w-6 h-6 text-white" />
            <span className="text-xl font-semibold text-white">5.5x More Reviews with Automation</span>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
