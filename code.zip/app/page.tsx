import { HeroSection } from "@/components/hero-section"
import { ProblemsWeFix } from "@/components/problems-we-fix"
import { WhoWeHelp } from "@/components/who-we-help"
import { ServicesGrid } from "@/components/services-grid"
import { RealResults } from "@/components/real-results"
import { ProcessSection } from "@/components/process-section"
import { CostComparison } from "@/components/cost-comparison"
import { AutomationFlow } from "@/components/automation-flow"
import { PricingSection } from "@/components/pricing-section"
import { PricingFAQ } from "@/components/pricing-faq"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <ProblemsWeFix />
      <WhoWeHelp />
      <ServicesGrid />
      <RealResults />
      <ProcessSection />
      <CostComparison />
      <AutomationFlow />
      <PricingSection />
      <PricingFAQ />
      <Footer />
    </main>
  )
}
