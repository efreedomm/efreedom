"use client"

import type React from "react"
import { Check, Zap, Crown, Send } from "lucide-react"

const pricingTiers = [
  {
    name: "Keep Jobs Coming Back",
    icon: Send,
    setup: "1,497",
    price: "597",
    period: "per month",
    description: "Make old customers book again—on autopilot.",
    features: [
      "CRM + customer pipeline setup",
      "Review & feedback automation",
      "Email + SMS follow-ups",
      "Performance dashboard",
      "Ongoing support & maintenance",
    ],
    cta: "Launch My System",
    popular: false,
  },
  {
    name: "Leads Every Week",
    icon: Zap,
    setup: "2,997",
    price: "1,497",
    period: "per month",
    description: "New jobs + repeat jobs, managed for you.",
    features: [
      "Everything in Launch",
      "WEBSITE DEVELOPMENT + landing funnel",
      "Local SEO + Google Business optimization",
      "AI chat & text assistant",
      "Ad campaign setup (Meta + Google)",
      "ROI dashboard + weekly reports",
    ],
    cta: "Start Growing",
    popular: true,
  },
  {
    name: "Hands-Free Growth Partner",
    icon: Crown,
    setup: "3,997",
    price: "2,497",
    period: "per month",
    description: "Your full revenue team—done-for-you growth.",
    features: [
      "Everything in Growth",
      "SEO on Chat GPT (GEO)",
      "24/7 AI call receptionist",
      "Retargeting ads + creative testing",
      "Review & SEO management",
      "Monthly strategy & optimization calls",
    ],
    cta: "Dominate My Market",
    popular: false,
  },
]

export function PricingSection() {
  const handlePricingClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault()
    const url = "https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
    if (typeof window !== "undefined" && (window as any).gtag_report_conversion) {
      ;(window as any).gtag_report_conversion(url)
    } else {
      window.open(url, "_blank")
    }
  }

  return (
    <section id="pricing" className="relative overflow-hidden bg-black py-32">
      {/* Background elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(255,255,255,0.03),transparent_50%)]" />
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:100px_100px]" />

      <div className="absolute bottom-0 left-0 right-0 h-32 opacity-20">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="hexPattern" x="0" y="0" width="56" height="100" patternUnits="userSpaceOnUse">
              <polygon points="28,0 56,15 56,45 28,60 0,45 0,15" fill="none" stroke="white" strokeWidth="0.5" />
              <polygon points="28,60 56,75 56,105 28,120 0,105 0,75" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#hexPattern)" />
        </svg>
      </div>

      <div className="relative mx-auto max-w-7xl px-4">
        {/* Header */}
        <div className="mb-20 text-center">
          <div>
            <h2 className="font-heading text-4xl tracking-wide text-white md:text-5xl lg:text-6xl">
              TRANSPARENT <span className="text-white">PRICING</span>
            </h2>
            <p className="mx-auto mt-6 max-w-3xl text-balance text-lg leading-relaxed text-white/70">
              Choose the plan that fits your ambition. Scale as you grow.
            </p>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid gap-8 lg:grid-cols-3">
          {pricingTiers.map((tier, index) => (
            <div
              key={index}
              className={`group relative overflow-hidden rounded-3xl border backdrop-blur-sm transition-all duration-300 ${
                tier.popular
                  ? "border-white bg-gradient-to-br from-zinc-900 to-black shadow-[0_0_60px_rgba(255,255,255,0.15)] lg:scale-105"
                  : "border-white/20 bg-gradient-to-br from-zinc-900/80 to-black/80 hover:border-white/40 hover:shadow-[0_0_40px_rgba(255,255,255,0.1)]"
              }`}
              style={{ willChange: "transform", transform: "translateZ(0)" }}
            >
              {/* Popular Badge */}
              {tier.popular && (
                <div className="absolute right-6 top-6 rounded-full bg-white px-4 py-1 text-xs font-bold tracking-wide text-black">
                  MOST POPULAR
                </div>
              )}

              {/* Particles */}
              {[...Array(8)].map((_, i) => (
                <div
                  key={i}
                  className="absolute bottom-0 w-1 h-1 bg-white rounded-full animate-particle-float"
                  style={{
                    left: `${15 + i * 10}%`,
                    animationDelay: `${i * 0.3}s`,
                    animationDuration: `${2 + Math.random() * 2}s`,
                  }}
                />
              ))}

              <div className="absolute inset-0 bg-gradient-to-br from-white/0 via-white/5 to-white/0 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

              <div className="relative p-8">
                {/* Icon */}
                

                {/* Tier Name */}
                <h3 className="mb-2 font-heading text-3xl tracking-wide text-white">{tier.name}</h3>

                {/* Description */}
                <p className="mb-6 text-balance text-sm leading-relaxed text-white/60">{tier.description}</p>

                {/* Price */}
                

                {/* CTA Button */}
                <a
                  href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
                  onClick={handlePricingClick}
                  className={`mb-8 block w-full rounded-xl py-4 text-center font-heading text-lg tracking-wide transition-all duration-300 ${
                    tier.popular
                      ? "bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.3)] hover:shadow-[0_0_30px_rgba(255,255,255,0.5)]"
                      : "border-2 border-white text-white hover:bg-white hover:text-black"
                  }`}
                >
                  {tier.cta}
                </a>

                {/* Features */}
                <div className="space-y-4">
                  {tier.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-3">
                      <div className="mt-1 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-white/20">
                        <Check className="h-3 w-3 text-white" />
                      </div>
                      <span className="text-sm leading-relaxed text-white/70">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Corner glow */}
              <div className="absolute -bottom-12 -right-12 h-48 w-48 rounded-full bg-white/5 blur-3xl transition-all duration-300 group-hover:bg-white/10" />
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <p className="mb-6 text-lg text-white/70">Not sure which plan is right for you?</p>
          <a
            href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
            onClick={handlePricingClick}
            className="group relative inline-block overflow-hidden border-2 border-white px-8 py-4 font-heading text-lg tracking-wide text-white transition-all duration-300 hover:bg-white hover:text-black"
          >
            <span className="relative z-10">SCHEDULE A CONSULTATION</span>
          </a>
        </div>
      </div>

      {/* CSS animation for particles */}
      <style jsx>{`
        @keyframes particle-float {
          0% {
            transform: translateY(0) scale(1);
            opacity: 0;
          }
          10% {
            opacity: 1;
          }
          90% {
            opacity: 0.5;
          }
          100% {
            transform: translateY(-400px) scale(0.3);
            opacity: 0;
          }
        }
        .animate-particle-float {
          animation: particle-float 3s ease-out infinite;
        }
      `}</style>
    </section>
  )
}
