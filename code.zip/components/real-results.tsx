"use client"

import { ArrowRight } from "lucide-react"
import { motion } from "framer-motion"

const caseStudies = [
  {
    industry: "E-commerce",
    business: "Online Retail Store",
    location: "New York, NY",
    metrics: [
      { label: "First Response Time", value: "45 seconds", percentage: 45 },
      { label: "Sales Closed in First Month", value: "23", percentage: 23 },
    ],
    quote: "Our system has been a game-changer for us.",
    link: "https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH",
  },
  {
    industry: "Professional Services",
    business: "Consulting Firm",
    location: "Los Angeles, CA",
    metrics: [
      { label: "Quote Follow-up Rate", value: "85%", percentage: 85 },
      { label: "Increase in Close Rate", value: "32%", percentage: 32 },
    ],
    quote: "With our system, we've seen a significant increase in our close rate.",
    link: "https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH",
  },
  {
    industry: "Healthcare",
    business: "Medical Practice",
    location: "Chicago, IL",
    metrics: [
      { label: "Automated Follow-ups", value: "Enabled", percentage: 100 },
      { label: "Monthly Bookings", value: "Doubled", percentage: 200 },
    ],
    quote: "No more missed leads with our automated follow-ups.",
    link: "https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH",
  },
]

export function RealResults() {
  const stars = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    size: Math.random() * 3 + 1,
    delay: Math.random() * 3,
    duration: Math.random() * 2 + 2,
  }))

  return (
    <section id="case-studies" className="relative overflow-hidden bg-black py-24">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,rgba(255,255,255,0.05),transparent_50%)]" />

      {stars.map((star) => (
        <div
          key={star.id}
          className="absolute animate-twinkle"
          style={{
            left: star.left,
            top: star.top,
            width: `${star.size}px`,
            height: `${star.size}px`,
            animationDelay: `${star.delay}s`,
            animationDuration: `${star.duration}s`,
          }}
        >
          <svg viewBox="0 0 24 24" fill="white" className="opacity-60">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
          </svg>
        </div>
      ))}

      <div className="relative mx-auto max-w-7xl px-4">
        {/* Header */}
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-4xl font-bold text-white md:text-5xl">
            See What We've Done for <span className="text-white">Businesses</span>
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-white/70">
            Real numbers from real businesses. These aren't projections—they're actual results from our automation
            system.
          </p>
        </div>

        {/* Case Studies Grid */}
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {caseStudies.map((study, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm transition-all duration-300 hover:border-white/30 hover:bg-white/10"
            >
              {/* Industry Badge */}
              <div className="mb-4 inline-block rounded-full bg-white/10 px-3 py-1">
                <span className="text-xs font-semibold text-white">{study.industry}</span>
              </div>

              {/* Business Name */}
              <h3 className="mb-2 text-xl font-bold text-white">{study.business}</h3>
              <p className="mb-6 text-sm text-white/60">{study.location}</p>

              {/* Key Metrics */}
              <div className="mb-6 space-y-4">
                {study.metrics.map((metric, idx) => (
                  <div key={idx}>
                    <div className="mb-1 flex items-baseline justify-between">
                      <span className="text-sm text-white/70">{metric.label}</span>
                      <span className="text-2xl font-bold text-white">{metric.value}</span>
                    </div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${metric.percentage}%` }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.5 + idx * 0.1, duration: 0.8 }}
                        className="h-full rounded-full bg-white"
                      />
                    </div>
                  </div>
                ))}
              </div>

              {/* Quote */}
              <blockquote className="border-l-2 border-white/20 pl-4 italic text-white/80">"{study.quote}"</blockquote>

              {/* Hover Effect */}
              <div className="absolute inset-0 -z-10 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <p className="mb-6 text-lg text-white/70">Ready to see similar results for your business?</p>
          <a
            href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
            className="inline-flex items-center gap-2 rounded-xl bg-white px-8 py-4 font-semibold text-black shadow-lg transition-all duration-300 hover:bg-white/90 hover:shadow-xl"
          >
            Get Your Free Strategy Call
            <ArrowRight className="h-5 w-5" />
          </a>
        </motion.div>
      </div>

      <style jsx>{`
        @keyframes twinkle {
          0%, 100% {
            opacity: 0.3;
            transform: scale(1);
          }
          50% {
            opacity: 1;
            transform: scale(1.2);
          }
        }
        .animate-twinkle {
          animation: twinkle 3s ease-in-out infinite;
        }
      `}</style>
    </section>
  )
}
