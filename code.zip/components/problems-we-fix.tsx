"use client"

const transformations = [
  {
    problem: "Missed calls = missed money",
    solution: "24/7 AI answers & books jobs instantly",
  },
  {
    problem: "Leads ghost you",
    solution: "We follow up till they say yes",
  },
  {
    problem: "You don't know what's working",
    solution: "Our dashboard shows every lead + ROI",
  },
  {
    problem: "No reviews, no trust",
    solution: "Review booster gets you 5-stars fast",
  },
  {
    problem: "Ads burn money",
    solution: "We track, test, and make them pay off",
  },
  {
    problem: "Website's just a brochure",
    solution: "We rebuild it to book jobs automatically",
  },
]

export function ProblemsWeFix() {
  return (
    null
  )
}
