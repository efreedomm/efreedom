"use client"

import dynamic from "next/dynamic"
import { Canvas } from "@react-three/fiber"
import { Suspense, useEffect, useState } from "react"

const Particles = dynamic(() => import("./particles").then((m) => ({ default: m.Particles })), { ssr: false })

export function ParticlesScene() {
  const [ok, setOk] = useState(true)
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const cnv = document.createElement("canvas")
    const gl2 = cnv.getContext("webgl2")
    const prefersReduced =
      typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches

    const checkMobile = typeof window !== "undefined" && window.innerWidth < 768
    setIsMobile(checkMobile)

    if (!gl2 || prefersReduced) setOk(false)
  }, [])

  if (!ok) return null

  const particleSize = isMobile ? 128 : 192

  return (
    <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 0 }}>
      <Canvas
        gl={{ antialias: false, powerPreference: "high-performance" }}
        dpr={[1, 1]}
        camera={{
          position: [0, 2, 5],
          fov: 50,
          near: 0.01,
          far: 300,
        }}
        frameloop="always"
        performance={{ min: 0.5 }}
      >
        <Suspense fallback={null}>
          <color attach="background" args={["#000000"]} />
          <Particles
            speed={0.5}
            aperture={1.79}
            focus={3.8}
            size={particleSize}
            noiseScale={0.6}
            noiseIntensity={0.4}
            timeScale={0.5}
            pointSize={isMobile ? 10.0 : 12.0}
            opacity={0.5}
            planeScale={10.0}
            introspect={false}
          />
        </Suspense>
      </Canvas>
    </div>
  )
}
