"use client"

import { Megaphone, FileText, MessageSquare, CreditCard, LayoutDashboard } from "lucide-react"

const steps = [
  { icon: Megaphone, label: "Ad" },
  { icon: FileText, label: "Form" },
  { icon: MessageSquare, label: "Text" },
  { icon: CreditCard, label: "Payment" },
  { icon: LayoutDashboard, label: "Dashboard" },
]

export function AutomationFlow() {
  return (
    null
  )
}
