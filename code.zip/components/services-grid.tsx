"use client"

import { motion } from "framer-motion"
import { Code, Phone, TrendingUp, Mail, MapPin, Search, Bot, Database, Star } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const items = [
  {
    icon: Code,
    t: "Website Development",
    b: "Ultra-fast, SSR, schema, AVIF, pixels—conversion OS from day one.",
    useImage: true,
    imageSrc: "/website-showcase.png",
    href: "/website-development",
  },
  {
    icon: Phone,
    t: "AI Call Receptionist",
    b: "24/7 voice agent that answers, qualifies, and books appointments.",
    useImage: true,
    imageSrc: "/ai-call-phone.png",
    href: "/ai-receptionist",
  },
  {
    icon: TrendingUp,
    t: "Digital Ads & Funnels",
    b: "Experiment → winner. Attribution to revenue. Scale without guesswork.",
    useImage: true,
    imageSrc: "/digital-ad-phone.png",
    href: "/digital-ads",
  },
  {
    icon: Mail,
    t: "Automated Communications",
    b: "Email/SMS follow-ups on autopilot. Nurture, revive, and close.",
    useImage: true,
    imageSrc: "/sms-automation-phone.png",
    href: "/automated-follow-ups",
  },
  {
    icon: MapPin,
    t: "Google Business Optimization",
    b: "Rank local, win maps, capture high-intent searches.",
    useImage: true,
    imageSrc: "/google-business-phone.png",
    href: "/reviews-engine",
  },
  {
    icon: Search,
    t: "Search Engine Optimization",
    b: "Technical + content engine for durable, compounding growth.",
    useImage: true,
    imageSrc: "/analytics-dashboard.png",
    href: "/local-seo",
  },
  {
    icon: Bot,
    t: "ChatGPT SEO known as GEO ",
    b: "Optimize your content to rank in ChatGPT and other AI-powered search engines. Get discovered when potential customers ask AI assistants about your services.",
    useImage: true,
    imageSrc: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-RxsJac5SS52CvhiGKKi6gvV159PjwH.png",
    href: "/chatgpt-seo",
  },
  {
    icon: Database,
    t: "CRM + Pipeline Systems",
    b: "Unified customer data, deal tracking, and revenue forecasting. One source of truth from lead to close.",
    useImage: true,
    imageSrc: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-mDEU7clxcfqgFj9fSRcGe05H8dQdjG.png",
    href: "/crm-pipeline",
  },
  {
    icon: Star,
    t: "Reputation & Review Booster",
    b: "Automate review requests, monitor reputation, and amplify 5-star feedback across all platforms.",
    useImage: true,
    imageSrc: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pzUAfbJyI2KAIA3STshscy3WKCfoMd.png",
    href: "/reputation-reviews",
  },
]

export function ServicesGrid() {
  const particles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    delay: `${Math.random() * 5}s`,
    duration: `${3 + Math.random() * 4}s`,
    size: `${2 + Math.random() * 3}px`,
  }))

  return (
    <section id="services" className="bg-black py-20 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        {particles.map((particle) => (
          <div
            key={particle.id}
            className="absolute bottom-0 rounded-full bg-white/30 animate-float-up"
            style={{
              left: particle.left,
              width: particle.size,
              height: particle.size,
              animationDelay: particle.delay,
              animationDuration: particle.duration,
            }}
          />
        ))}
      </div>

      <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
        <defs>
          <linearGradient id="waveGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="rgba(255,255,255,0)" />
            <stop offset="50%" stopColor="rgba(255,255,255,0.3)" />
            <stop offset="100%" stopColor="rgba(255,255,255,0)" />
          </linearGradient>

          <filter id="glow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        <path d="M 20% 25% Q 35% 20%, 50% 25%" stroke="url(#waveGradient)" strokeWidth="1" fill="none" opacity="0.4" />
        <circle r="3" fill="white" opacity="0.8" filter="url(#glow)">
          <animateMotion dur="3s" repeatCount="indefinite" path="M 20% 25% Q 35% 20%, 50% 25%" />
        </circle>

        <path d="M 50% 25% Q 65% 30%, 80% 25%" stroke="url(#waveGradient)" strokeWidth="1" fill="none" opacity="0.4" />
        <circle r="3" fill="white" opacity="0.8" filter="url(#glow)">
          <animateMotion dur="3s" repeatCount="indefinite" begin="0.5s" path="M 50% 25% Q 65% 30%, 80% 25%" />
        </circle>

        <path d="M 20% 60% Q 35% 65%, 50% 60%" stroke="url(#waveGradient)" strokeWidth="1" fill="none" opacity="0.4" />
        <circle r="3" fill="white" opacity="0.8" filter="url(#glow)">
          <animateMotion dur="3.5s" repeatCount="indefinite" begin="1s" path="M 20% 60% Q 35% 65%, 50% 60%" />
        </circle>

        <path d="M 50% 60% Q 65% 55%, 80% 60%" stroke="url(#waveGradient)" strokeWidth="1" fill="none" opacity="0.4" />
        <circle r="3" fill="white" opacity="0.8" filter="url(#glow)">
          <animateMotion dur="3.5s" repeatCount="indefinite" begin="1.5s" path="M 50% 60% Q 65% 55%, 80% 60%" />
        </circle>

        <path d="M 25% 35% Q 20% 47%, 25% 55%" stroke="url(#waveGradient)" strokeWidth="1" fill="none" opacity="0.4" />
        <circle r="3" fill="white" opacity="0.8" filter="url(#glow)">
          <animateMotion dur="4s" repeatCount="indefinite" begin="0.3s" path="M 25% 35% Q 20% 47%, 25% 55%" />
        </circle>

        <path d="M 50% 35% Q 55% 47%, 50% 55%" stroke="url(#waveGradient)" strokeWidth="1" fill="none" opacity="0.4" />
        <circle r="3" fill="white" opacity="0.8" filter="url(#glow)">
          <animateMotion dur="4s" repeatCount="indefinite" begin="0.8s" path="M 50% 35% Q 55% 47%, 50% 55%" />
        </circle>

        <path d="M 75% 35% Q 80% 47%, 75% 55%" stroke="url(#waveGradient)" strokeWidth="1" fill="none" opacity="0.4" />
        <circle r="3" fill="white" opacity="0.8" filter="url(#glow)">
          <animateMotion dur="4s" repeatCount="indefinite" begin="1.3s" path="M 75% 35% Q 80% 47%, 75% 55%" />
        </circle>

        <path d="M 45% 35% Q 50% 45%, 55% 55%" stroke="url(#waveGradient)" strokeWidth="1" fill="none" opacity="0.3" />
        <circle r="2.5" fill="white" opacity="0.6" filter="url(#glow)">
          <animateMotion dur="5s" repeatCount="indefinite" begin="2s" path="M 45% 35% Q 50% 45%, 55% 55%" />
        </circle>
      </svg>

      <div className="mx-auto max-w-7xl px-6 relative z-10">
        <h2 className="text-5xl md:text-7xl font-display font-bold relative sweep animate text-white">What We Build</h2>
        <p className="text-text/85 mt-4 max-w-2xl text-lg">
          Pick your driver. Every service is wired into the AI revenue OS.
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          {items.map((it, index) => {
            const Icon = it.icon
            return (
              <Link key={it.t} href={it.href}>
                <motion.div
                  whileHover={{ rotateX: -2, rotateY: 2, y: -4 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  className="group text-left rounded-2xl hairline bg-slate/60 backdrop-blur-md p-6 cursor-pointer"
                  style={{ perspective: "1000px" }}
                >
                  <div className="h-40 rounded-xl border border-white/10 mb-6 bg-gradient-to-br from-slate to-black group-hover:shadow-[0_8px_32px_rgba(255,255,255,0.2)] transition-shadow duration-300 flex items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-tr from-white/5 to-transparent group-hover:opacity-100 transition-opacity duration-300 border-primary text-transparent bg-slate-500 opacity-[0.07]" />
                    {it.useImage ? (
                      <Image
                        src={it.imageSrc! || "/placeholder.svg"}
                        alt={it.t}
                        width={500}
                        height={350}
                        className="object-cover h-full group-hover:opacity-100 transition-opacity duration-300 w-full opacity-80 scale-110"
                      />
                    ) : (
                      <Icon
                        className="w-16 h-16 text-white/60 group-hover:text-white transition-colors duration-300"
                        strokeWidth={1.5}
                      />
                    )}
                  </div>
                  <h3 className="text-2xl font-semibold text-frost mb-2 text-primary">{it.t}</h3>
                  <p className="text-text leading-relaxed">{it.b}</p>
                </motion.div>
              </Link>
            )
          })}
        </div>
      </div>

      <style jsx>{`
        @keyframes float-up {
          0% {
            transform: translateY(0) scale(1);
            opacity: 0;
          }
          10% {
            opacity: 0.3;
          }
          90% {
            opacity: 0.3;
          }
          100% {
            transform: translateY(-100vh) scale(0.5);
            opacity: 0;
          }
        }
        .animate-float-up {
          animation: float-up linear infinite;
        }
      `}</style>
    </section>
  )
}
