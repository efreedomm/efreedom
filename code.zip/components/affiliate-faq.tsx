"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

export function AffiliateFAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  const faqs = [
    {
      question: "How much can I earn as an affiliate?",
      answer:
        "You'll earn 20% recurring commission on all payments from clients you refer. With our pricing ranging from $997-$4,997/month, you can earn $199-$999 per client per month. There's no cap on how many clients you can refer.",
    },
    {
      question: "How do I get paid?",
      answer:
        "Commissions are paid monthly via direct deposit or PayPal. You'll receive payment for all active clients you've referred. We provide a detailed dashboard where you can track your earnings and referrals in real-time.",
    },
    {
      question: "Do I need to be technical to promote eFreedom?",
      answer:
        "Not at all! We provide all the marketing materials, landing pages, and content you need. Your job is simply to share your unique affiliate link with your network. We handle all the technical implementation and client support.",
    },
    {
      question: "What kind of support do you provide?",
      answer:
        "You'll get access to our affiliate portal with marketing materials, email templates, social media content, and tracking tools. Plus, you'll have a dedicated affiliate manager to help you succeed and answer any questions.",
    },
    {
      question: "How long do I earn commissions?",
      answer:
        "You earn recurring commissions for as long as your referred client remains active with eFreedom. If a client stays for years, you continue earning monthly commissions throughout that entire period.",
    },
    {
      question: "Is there a minimum number of referrals required?",
      answer:
        "No minimum required! Whether you refer one client or one hundred, you'll earn commissions on each one. Start small and scale at your own pace. Many of our top affiliates started with just one referral.",
    },
  ]

  return (
    <section className="relative overflow-hidden bg-black py-24">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,rgba(255,255,255,0.03),transparent_60%)]" />

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.5, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Number.POSITIVE_INFINITY,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="relative mx-auto max-w-4xl px-4">
        {/* Header */}
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-4xl font-bold text-white md:text-5xl">Frequently Asked Questions</h2>
          <p className="text-lg text-white/70">Everything you need to know about the eFreedom Affiliate Program</p>
        </div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="overflow-hidden rounded-xl border border-white/10 bg-white/5 backdrop-blur-sm"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="flex w-full items-center justify-between p-6 text-left transition-colors hover:bg-white/5"
              >
                <span className="text-lg font-semibold text-white">{faq.question}</span>
                <motion.div
                  animate={{ rotate: openIndex === index ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="flex-shrink-0 ml-4"
                >
                  <ChevronDown className="h-5 w-5 text-white" />
                </motion.div>
              </button>

              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="border-t border-white/10 px-6 py-4">
                      <p className="text-white/70 leading-relaxed">{faq.answer}</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <p className="mb-6 text-lg text-white/70">Still have questions?</p>
          <a
            href="mailto:affiliates@efreedom.com"
            className="inline-flex items-center gap-2 rounded-full bg-white px-8 py-4 font-semibold text-black transition-all hover:scale-105 hover:shadow-lg hover:shadow-white/20"
          >
            Contact Our Affiliate Team
          </a>
        </motion.div>
      </div>
    </section>
  )
}
