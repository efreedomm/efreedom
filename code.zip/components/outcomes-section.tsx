"use client"

import { ArrowUpRight } from "lucide-react"

const outcomes = [
  {
    metric: "120%",
    label: "Average ROI Increase",
    description: "Clients see exponential returns within the first quarter",
  },
  {
    metric: "24/7",
    label: "AI-Powered Operations",
    description: "Always Available to respond to customers",
  },
  {
    metric: "89%",
    label: "Cost Reduction",
    description: "Streamlined processes eliminate operational waste",
  },
  {
    metric: "3x",
    label: "Faster Decision Making",
    description: "Real-time insights accelerate strategic pivots",
  },
]

export function OutcomesSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#0B121D] via-[#1A2332] to-[#0B121D] py-32">
      {/* Radial glow */}
      <div className="absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#C6A564]/10 blur-[120px]" />

      {/* Header */}
      <div className="relative mx-auto max-w-7xl px-4">
        <div className="mb-20 text-center">
          <div>
            <h2 className="font-heading text-4xl tracking-wide text-white md:text-5xl lg:text-6xl">
              MEASURABLE <span className="text-[#C6A564]">IMPACT</span>
            </h2>
            <p className="mx-auto mt-6 max-w-3xl text-balance text-lg leading-relaxed text-white/70">
              Our AI-powered solutions deliver measurable results that transform businesses from the ground up
            </p>
          </div>
        </div>

        {/* Outcomes Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {outcomes.map((outcome, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl border border-[#C6A564]/20 bg-gradient-to-br from-[#1A2332]/80 to-[#0B121D]/80 p-8 backdrop-blur-sm transition-all hover:border-[#C6A564]/40 hover:shadow-[0_0_40px_rgba(198,165,100,0.2)]"
            >
              {/* Animated gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#C6A564]/0 via-[#C6A564]/5 to-[#C6A564]/0 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

              <div className="relative">
                {/* Metric */}
                <div className="mb-4 flex items-start justify-between">
                  <h3 className="font-heading text-6xl tracking-tight text-[#C6A564] md:text-7xl">{outcome.metric}</h3>
                  <ArrowUpRight className="h-6 w-6 text-[#C6A564]/60 transition-all group-hover:translate-x-1 group-hover:-translate-y-1 group-hover:text-[#C6A564]" />
                </div>

                {/* Label */}
                <h4 className="mb-3 font-heading text-xl tracking-wide text-white">{outcome.label}</h4>

                {/* Description */}
                <p className="text-balance leading-relaxed text-white/60">{outcome.description}</p>

                {/* Decorative line */}
                <div className="mt-6 h-1 w-16 rounded-full bg-gradient-to-r from-[#C6A564] to-transparent transition-all group-hover:w-24" />
              </div>

              {/* Corner accent */}
              <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-[#C6A564]/5 blur-2xl transition-all group-hover:bg-[#C6A564]/10" />
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center"></div>
      </div>
    </section>
  )
}
