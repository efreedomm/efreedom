"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Plus, Minus } from "lucide-react"

const faqs = [
  {
    question: "What's included in the setup?",
    answer:
      "We build your complete AI system: custom chatbot trained on your business, automated booking flows, follow-up sequences, and integration with your existing tools. Everything is done for you—no technical work required on your end.",
  },
  {
    question: "How quickly will I see results?",
    answer:
      "Most clients see their first AI-booked appointment within the first week. The system works 24/7 from day one, so you start capturing leads immediately while we continue optimizing performance.",
  },
  {
    question: "Do I need any technical knowledge?",
    answer:
      "None at all. We handle everything—setup, training, integration, and ongoing optimization. You just watch the bookings come in and focus on serving your customers.",
  },
  {
    question: "What if the AI doesn't book jobs in the first 2 months?",
    answer:
      "If you're on the Hands-Free Growth Partner plan and don't get a booked job by Month 2, we work for free until you do. We're that confident in our system—and we put our money where our mouth is.",
  },
  {
    question: "Can I cancel anytime?",
    answer:
      "Yes. All plans are month-to-month with no long-term contracts. If you're not happy, you can cancel anytime. But we're confident you'll love the results.",
  },
  {
    question: "How is this different from hiring a VA or receptionist?",
    answer:
      "A VA costs $3,000-5,000/month, works limited hours, needs training, and can still miss calls. Our AI works 24/7, never takes a day off, handles unlimited conversations simultaneously, and costs a fraction of the price. Plus, it gets smarter over time.",
  },
  {
    question: "What industries does this work for?",
    answer:
      "We work with service-based businesses across all industries: professional services, healthcare, real estate, e-commerce, consulting, and more. If you book appointments and lose revenue from missed calls, this works for you.",
  },
  {
    question: "How do I know if this is right for my business?",
    answer:
      "If you're missing calls, losing leads to competitors, or spending too much time on repetitive tasks, this is for you. Book a free strategy call and we'll show you exactly how eFreedom can transform your business.",
  },
]

export function PricingFAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  return (
    <section className="relative overflow-hidden bg-black py-24">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.03),transparent_70%)]" />

      <div className="relative mx-auto max-w-4xl px-4">
        {/* Header */}
        <div className="mb-16 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="font-display text-4xl font-bold tracking-tight text-white sm:text-5xl">
              Frequently Asked Questions
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-white/70">
              Everything you need to know about our AI automation system
            </p>
          </motion.div>
        </div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="overflow-hidden rounded-2xl border border-white/20 bg-white/5 backdrop-blur-sm transition-all duration-300 hover:border-white/30"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="flex w-full items-center justify-between gap-4 p-6 text-left transition-colors"
              >
                <span className="font-display text-lg font-semibold text-white">{faq.question}</span>
                <div className="flex-shrink-0">
                  {openIndex === index ? (
                    <Minus className="h-5 w-5 text-white transition-transform" />
                  ) : (
                    <Plus className="h-5 w-5 text-white transition-transform" />
                  )}
                </div>
              </button>

              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="border-t border-white/10 px-6 pb-6 pt-4">
                      <p className="text-white/70 leading-relaxed">{faq.answer}</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
