"use client"

import { Zap, Search, Cog, Rocket, TrendingUp } from "lucide-react"

const steps = [
  {
    icon: Search,
    title: "We Learn Your Business",
    description:
      "We look at how you get customers now, spot the holes, and build a simple plan that guarantees more booked jobs.",
  },
  {
    icon: Cog,
    title: "We Build Your System",
    description:
      "We set up your CRM, automations, emails, texts, and tracking. Everything connects so leads never slip through.",
  },
  {
    icon: Zap,
    title: "We Turn It On",
    description:
      "Your system goes live. AI follows up, books calls, and keeps your pipeline full while we monitor everything.",
  },
  {
    icon: Rocket,
    title: "We Scale the Results",
    description:
      "Once the foundation works, we add ads, SEO, and reviews to multiply your calls and revenue month after month.",
  },
  {
    icon: TrendingUp,
    title: "We Guarantee It Works",
    description:
      "We track booked jobs and revenue—not clicks. If your results aren't there by month 2, we work free until they are.",
  },
]

export function ProcessSection() {
  return (
    null
  )
}
