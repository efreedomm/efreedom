"use client"

import type React from "react"
import Image from "next/image"
import { ParticlesScene } from "@/components/particles-scene"

export function HeroSection() {
  const handleBookingClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault()
    const url = "https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
    if (typeof window !== "undefined" && (window as any).gtag_report_conversion) {
      ;(window as any).gtag_report_conversion(url)
    } else {
      window.open(url, "_blank")
    }
  }

  return (
    <section className="relative h-[100svh] min-h-[660px] overflow-clip">
      <ParticlesScene />

      <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/30 pointer-events-none" />

      <div className="absolute top-12 left-0 right-0 z-10 flex justify-center">
        <Image
          src="/images/design-mode/Untitled%20design%20%2822%29.png"
          alt="StrivePoint Consulting"
          width={120}
          height={40}
          className="opacity-90"
        />
      </div>

      <div className="relative z-10 grid place-content-center h-full text-center px-6 pt-20">
        <h1 className="font-display font-black tracking-tight text-[clamp(36px,7vw,90px)] leading-[0.95]">
          We Turn Missed Calls Into <span className="text-white">Booked Jobs</span>
        </h1>
        <p className="max-w-3xl mx-auto text-text text-lg md:text-xl mt-6 leading-relaxed">
          Automation system that never sleeps. eFreedom books jobs, follows up,optomize your search, and grows your
          business 24/7.
        </p>

        <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
            onClick={handleBookingClick}
            className="px-6 py-3 rounded-xl bg-white text-black font-semibold shadow-[0_8px_24px_rgba(255,255,255,0.3)] hover:shadow-[0_14px_48px_rgba(255,255,255,0.5)] hover:bg-white/90 transition-all duration-300"
          >
            Book Strategy Call (Free)
          </a>
        </div>

        <div className="mt-6">
          <a
            href="/affiliate"
            className="text-sm text-white/60 hover:text-white/90 transition-colors duration-300 underline decoration-white/30 hover:decoration-white/60"
          >
            Become An Affiliate
          </a>
        </div>

        <div className="mt-12 flex flex-wrap items-center justify-center gap-4 text-sm text-white/60">
          <span className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-[#5ca16b] bg-foreground"></span>
            Trusted by 40+ businesses
          </span>
          <span className="hidden sm:inline text-white/30">•</span>
          <span className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-[#5ca16b] bg-foreground"></span>
            California
          </span>
          <span className="hidden sm:inline text-white/30">•</span>
          <span className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-[#5ca16b] bg-foreground"></span>
            Revenue Assurance
          </span>
        </div>
      </div>
    </section>
  )
}
