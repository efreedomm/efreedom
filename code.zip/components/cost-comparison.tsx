"use client"

import { Check, ArrowRight } from "lucide-react"

const features = [
  { name: "CRM & Customer Pipeline", replaces: "HubSpot, Pipedrive", cost: 99 },
  { name: "Website Builder & Landing Funnels", replaces: "Wix, ClickFunnels", cost: 297 },
  { name: "Email + SMS Marketing", replaces: "Mailchimp, Twilio, ActiveCampaign", cost: 198 },
  { name: "Booking & Scheduling", replaces: "Calendly", cost: 29 },
  { name: "Workflow Automations", replaces: "Zapier, Monday, Airtable", cost: 169 },
  { name: "Review & Feedback Automation", replaces: "Birdeye, Podium", cost: 159 },
  { name: "AI Chat & Text Assistant", replaces: "ManyChat, Chatbase", cost: 49 },
  { name: "SEO & Google Business Optimization", replaces: "BrightLocal, SEMrush", cost: 99 },
  { name: "Ad Campaign Setup (Meta + Google)", replaces: "Agencies / Freelancers", cost: 750 },
  { name: "ROI Dashboard + Weekly Reports", replaces: "AgencyAnalytics, DashThis", cost: 299 },
  { name: "24/7 AI Call Receptionist", replaces: "Ruby Receptionists, Smith.ai", cost: 300 },
  { name: "Retargeting & Creative Testing", replaces: "Meta Ad Library Tools", cost: 99 },
  { name: "Monthly Strategy Calls & Optimization", replaces: "Marketing Consultant", cost: 250 },
  { name: "Full Rebrand + Website Redesign", replaces: "Web Designer", cost: 0, note: "$2,000 setup" },
  { name: "Ongoing Support & Maintenance", replaces: "Tech / Admin Staff", cost: 400 },
]

export function CostComparison() {
  const totalCost = features.reduce((sum, f) => sum + f.cost, 0)
  const savings = totalCost - 297

  const scrollToPricing = () => {
    const pricingSection = document.querySelector("#pricing")
    pricingSection?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section className="relative overflow-hidden bg-black py-24">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,rgba(255,255,255,0.05),transparent_50%)]" />
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:100px_100px]" />

      <div className="relative mx-auto max-w-7xl px-4">
        {/* Header */}
        <div className="mb-16 text-center">
          <h2 className="font-display text-4xl font-bold tracking-tight text-white md:text-5xl lg:text-6xl">
            Why Businesses Choose <span className="text-white">{"eFreedom"}</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-white/70">
            Replace 15+ tools with one intelligent system — and save thousands every month
          </p>
        </div>

        {/* Table Container */}
        <div
          className="overflow-x-auto rounded-2xl border border-white/20 bg-black/50 backdrop-blur-sm"
          style={{ willChange: "transform", transform: "translateZ(0)" }}
        >
          <table className="w-full min-w-[800px]">
            <thead>
              <tr className="border-b border-white/20">
                <th className="px-6 py-4 text-left font-display text-sm font-bold uppercase tracking-wider text-white">
                  Features
                </th>
                <th className="px-6 py-4 text-left font-display text-sm font-bold uppercase tracking-wider text-white">
                  Replaces / Requires
                </th>
                <th className="px-6 py-4 text-right font-display text-sm font-bold uppercase tracking-wider text-white">
                  Monthly Cost With Others
                </th>
                <th className="px-6 py-4 text-center font-display text-sm font-bold uppercase tracking-wider text-white">
                  Included
                </th>
              </tr>
            </thead>
            <tbody>
              {features.map((feature) => (
                <tr
                  key={feature.name}
                  className="border-b border-white/10 transition-colors duration-200 hover:bg-white/5"
                >
                  <td className="px-6 py-4 font-medium text-white">{feature.name}</td>
                  <td className="px-6 py-4 text-sm text-white/60">{feature.replaces}</td>
                  <td className="px-6 py-4 text-right font-mono text-white">
                    {feature.cost > 0 ? `$${feature.cost}` : feature.note}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-white/20">
                      <Check className="h-5 w-5 text-white" />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Totals */}
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {/* Other Tools Cost */}
          <div className="rounded-2xl border border-red-500/30 bg-red-500/5 p-6 backdrop-blur-sm">
            <div className="mb-2 text-sm font-medium uppercase tracking-wider text-red-400">
              Total Cost Using Other Tools
            </div>
            <div className="font-display text-4xl font-bold text-white">${totalCost.toLocaleString()}/month</div>
            <div className="mt-1 text-sm font-semibold text-destructive">
              + setup fees & maintenance, estimated $3,000
            </div>
          </div>

          {/* StrivePoint Cost */}
          <div className="rounded-2xl border border-white/30 bg-white/5 p-6 backdrop-blur-sm">
            <div className="mb-2 text-sm font-medium uppercase tracking-wider text-white">
              Total Cost With StrivePoint
            </div>
            <div className="font-display text-4xl font-bold text-white">Starting at $597/month</div>
            <div className="mt-2 flex items-center gap-2 text-lg font-semibold text-green-400">
              <span> Save Over $2,600 month</span>
            </div>
          </div>
        </div>

        {/* Bonus Note */}
        <div className="mt-6 rounded-xl border border-white/20 bg-white/5 p-6 text-center backdrop-blur-sm">
          <p className="text-lg text-white">
            <span className="font-semibold text-white">Bonus:</span> No separate logins, no setup headaches, no
            hiring — one system does it all for you.
          </p>
        </div>

        {/* CTA Button */}
        <div className="mt-12 text-center">
          <button
            onClick={scrollToPricing}
            className="group inline-flex items-center gap-2 rounded-full bg-white px-8 py-4 font-display text-lg font-bold text-black transition-all duration-300 hover:scale-105 hover:bg-white/90 hover:shadow-[0_0_30px_rgba(255,255,255,0.3)]"
          >
            SEE HOW MUCH YOU'LL SAVE
            <ArrowRight className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
          </button>
        </div>
      </div>
    </section>
  )
}
