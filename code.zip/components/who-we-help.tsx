"use client"

import {
  Store,
  Utensils,
  Briefcase,
  Heart,
  Dumbbell,
  GraduationCap,
  Home,
  Car,
  Scissors,
  Coffee,
  Building2,
  Stethoscope,
  ShoppingBag,
  Laptop,
  CheckCircle2,
} from "lucide-react"
import { Carousel, CarouselContent, CarouselItem, CarouselPrevious, CarouselNext } from "@/components/ui/carousel"

const industries = [
  {
    icon: Utensils,
    title: "Restaurants",
    description: "Automated booking and customer engagement for food service.",
    features: ["24/7 reservation system", "Customer follow-ups", "Review management"],
  },
  {
    icon: Store,
    title: "Retail Stores",
    description: "Drive foot traffic and online sales with smart automation.",
    features: ["Lead capture", "Inventory alerts", "Customer retention"],
  },
  {
    icon: Stethoscope,
    title: "Healthcare",
    description: "Patient scheduling and communication made effortless.",
    features: ["Appointment booking", "Reminder systems", "Patient engagement"],
  },
  {
    icon: Home,
    title: "Real Estate",
    description: "Never miss a potential buyer or seller again.",
    features: ["Lead qualification", "Property inquiries", "Tour scheduling"],
  },
  {
    icon: Dumbbell,
    title: "Fitness Centers",
    description: "Keep members engaged and classes fully booked.",
    features: ["Class bookings", "Membership follow-ups", "Retention campaigns"],
  },
  {
    icon: Briefcase,
    title: "Professional Services",
    description: "Streamline client acquisition for consultants and agencies.",
    features: ["Consultation booking", "Client onboarding", "Follow-up automation"],
  },
  {
    icon: GraduationCap,
    title: "Education",
    description: "Enrollment and student engagement on autopilot.",
    features: ["Course registration", "Student communication", "Event management"],
  },
  {
    icon: Car,
    title: "Automotive",
    description: "Service appointments and customer retention for auto shops.",
    features: ["Service scheduling", "Maintenance reminders", "Customer loyalty"],
  },
  {
    icon: Scissors,
    title: "Salons & Spas",
    description: "Keep your calendar full with automated booking.",
    features: ["Appointment management", "Client reminders", "Rebooking campaigns"],
  },
  {
    icon: Coffee,
    title: "Hospitality",
    description: "Enhance guest experience with smart automation.",
    features: ["Reservation systems", "Guest communication", "Feedback collection"],
  },
  {
    icon: Building2,
    title: "Property Management",
    description: "Tenant communication and maintenance requests simplified.",
    features: ["Maintenance scheduling", "Tenant portals", "Lease renewals"],
  },
  {
    icon: Laptop,
    title: "Tech & SaaS",
    description: "Convert demos into customers with automated follow-ups.",
    features: ["Demo scheduling", "Trial management", "Onboarding automation"],
  },
  {
    icon: ShoppingBag,
    title: "E-commerce",
    description: "Recover abandoned carts and boost repeat purchases.",
    features: ["Cart recovery", "Order follow-ups", "Customer loyalty"],
  },
  {
    icon: Heart,
    title: "Wellness",
    description: "Client scheduling and engagement for wellness professionals.",
    features: ["Session booking", "Client check-ins", "Program management"],
  },
]

export function WhoWeHelp() {
  return (
    <section className="relative overflow-hidden bg-black py-24">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(255,255,255,0.03),transparent_50%)]" />

      <div className="relative mx-auto max-w-7xl px-4 mb-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-black text-white mb-4">Who We Help</h2>
          <p className="text-lg text-white/70 max-w-2xl mx-auto">
            Specialized solutions for businesses across industries
          </p>
          <p className="text-sm text-white/50 mt-2 max-w-xl mx-auto">
            We help anyone willing to help their business grow
          </p>
        </div>

        {/* Carousel */}
        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full"
        >
          <CarouselContent className="-ml-4">
            {industries.map((industry, index) => (
              <CarouselItem key={index} className="pl-4 md:basis-1/2 lg:basis-1/3">
                <div className="group relative h-full">
                  {/* Icon */}
                  <div className="mb-6 inline-flex h-16 w-16 items-center justify-center rounded-xl bg-white/5 border border-white/10 transition-all duration-500 group-hover:bg-white/10 group-hover:border-white/20">
                    <industry.icon className="h-8 w-8 text-white transition-transform duration-500 group-hover:scale-110" />
                  </div>

                  {/* Content */}
                  <h3 className="text-2xl font-display font-bold text-white mb-3 transition-colors duration-300">
                    {industry.title}
                  </h3>
                  <p className="text-white/60 mb-6 leading-relaxed">{industry.description}</p>

                  {/* Features */}
                  <ul className="space-y-3">
                    {industry.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-3 text-sm text-white/70">
                        <CheckCircle2 className="h-5 w-5 text-white flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Hover glow effect */}
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/0 via-white/0 to-white/5 opacity-0 transition-opacity duration-500 group-hover:opacity-100 pointer-events-none" />
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <CarouselPrevious className="relative static translate-y-0 h-12 w-12 rounded-full border-white/20 bg-white/5 hover:bg-white/10 hover:border-white/30 transition-all duration-300" />
            <CarouselNext className="relative static translate-y-0 h-12 w-12 rounded-full border-white/20 bg-white/5 hover:bg-white/10 hover:border-white/30 transition-all duration-300" />
          </div>
        </Carousel>
      </div>
    </section>
  )
}
