"use client"

import type React from "react"
import { motion } from "framer-motion"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { ChevronDown, Menu, X } from "lucide-react"

const solutions = [
  { name: "AI Receptionist", href: "/ai-receptionist" },
  { name: "Automated Follow-Ups", href: "/automated-follow-ups" },
  { name: "Digital Ads", href: "/digital-ads" },
  { name: "Local SEO", href: "/local-seo" },
  { name: "ChatGPT SEO (GEO)", href: "/chatgpt-seo" },
  { name: "CRM + Pipeline Systems", href: "/crm-pipeline" },
  { name: "Website Development", href: "/website-development" },
  { name: "Reviews Engine", href: "/reviews-engine" },
]

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isPastHero, setIsPastHero] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isSolutionsOpen, setIsSolutionsOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY
      const heroHeight = window.innerHeight

      setIsScrolled(scrollY > 20)
      setIsPastHero(scrollY > heroHeight)
    }
    handleScroll()
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    setIsMobileMenuOpen(false)
    setIsSolutionsOpen(false)

    if (href.startsWith("#")) {
      e.preventDefault()

      if (pathname === "/") {
        const element = document.querySelector(href)
        if (element) {
          element.scrollIntoView({ behavior: "smooth" })
        }
      } else {
        router.push(`/${href}`)
      }
    }
  }

  return (
    <header
      className={`sticky top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-black/95 backdrop-blur-md shadow-lg" : "bg-black/80 backdrop-blur-sm"
      }`}
    >
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div
          className={`flex justify-between items-center my-0 gap-0 transition-all duration-300 mx-10 px-0 ${
            isScrolled ? "h-14" : "h-20"
          }`}
        >
          {/* Logo */}

          {/* Desktop Navigation */}
          <div
            className={`hidden lg:flex lg:items-center lg:gap-8 mx-40 transition-all duration-300 ${
              isScrolled ? "scale-95" : "scale-100"
            }`}
          >
            <Link href="/" className="text-white/90 hover:text-[#88a183] transition-colors relative group">
              Home
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#88a183] transition-all duration-300 group-hover:w-full" />
            </Link>

            <Link href="/how-it-works" className="text-white/90 hover:text-[#88a183] transition-colors relative group">
              How It Works
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#88a183] transition-all duration-300 group-hover:w-full" />
            </Link>

            {/* Solutions Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsSolutionsOpen(!isSolutionsOpen)}
                className="flex items-center gap-1 text-white/90 hover:text-[#88a183] transition-colors relative group"
              >
                Solutions
                <ChevronDown className={`w-4 h-4 transition-transform ${isSolutionsOpen ? "rotate-180" : ""}`} />
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#88a183] transition-all duration-300 group-hover:w-full" />
              </button>

              {isSolutionsOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute top-full left-0 mt-2 w-64 backdrop-blur-md border border-white/10 rounded-lg shadow-xl py-2 z-50 bg-black"
                >
                  <Link
                    href="/ai-receptionist"
                    className="block px-4 py-2 text-white/90 hover:bg-white/5 hover:text-[#88a183] transition-colors"
                    onClick={() => setIsSolutionsOpen(false)}
                  >
                    AI Receptionist
                  </Link>
                  <Link
                    href="/automated-follow-ups"
                    className="block px-4 py-2 text-white/90 hover:bg-white/5 hover:text-[#88a183] transition-colors"
                    onClick={() => setIsSolutionsOpen(false)}
                  >
                    Automated Follow-Ups
                  </Link>
                  <Link
                    href="/digital-ads"
                    className="block px-4 py-2 text-white/90 hover:bg-white/5 hover:text-[#88a183] transition-colors"
                    onClick={() => setIsSolutionsOpen(false)}
                  >
                    Digital Ads
                  </Link>
                  <Link
                    href="/local-seo"
                    className="block px-4 py-2 text-white/90 hover:bg-white/5 hover:text-[#88a183] transition-colors"
                    onClick={() => setIsSolutionsOpen(false)}
                  >
                    Local SEO
                  </Link>
                  <Link
                    href="/chatgpt-seo"
                    className="block px-4 py-2 text-white/90 hover:bg-white/5 hover:text-[#88a183] transition-colors"
                    onClick={() => setIsSolutionsOpen(false)}
                  >
                    ChatGPT SEO (GEO)
                  </Link>
                  <Link
                    href="/crm-pipeline"
                    className="block px-4 py-2 text-white/90 hover:bg-white/5 hover:text-[#88a183] transition-colors"
                    onClick={() => setIsSolutionsOpen(false)}
                  >
                    CRM + Pipeline Systems
                  </Link>
                  <Link
                    href="/website-development"
                    className="block px-4 py-2 text-white/90 hover:bg-white/5 hover:text-[#88a183] transition-colors"
                    onClick={() => setIsSolutionsOpen(false)}
                  >
                    Website Development
                  </Link>
                  <Link
                    href="/reviews-engine"
                    className="block px-4 py-2 text-white/90 hover:bg-white/5 hover:text-[#88a183] transition-colors"
                    onClick={() => setIsSolutionsOpen(false)}
                  >
                    Reviews Engine
                  </Link>
                </motion.div>
              )}
            </div>

            <Link href="/pricing" className="text-white/90 hover:text-[#88a183] transition-colors relative group">
              Pricing
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#88a183] transition-all duration-300 group-hover:w-full" />
            </Link>

            <Link href="/case-studies" className="text-white/90 hover:text-[#88a183] transition-colors relative group">
              Case Studies
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#88a183] transition-all duration-300 group-hover:w-full" />
            </Link>

            <Link href="/about" className="text-white/90 hover:text-[#88a183] transition-colors relative group">
              About
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#88a183] transition-all duration-300 group-hover:w-full" />
            </Link>

            {/* CTA Button */}
            <a
              href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-2.5 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 shadow-lg hover:shadow-[0_8px_24px_rgba(255,255,255,0.3)]"
            >
              Book Call
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden text-white/90 hover:text-[#88a183] transition-colors"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-white/10">
            <div className="flex flex-col gap-4">
              <Link
                href="/"
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-white/90 hover:text-[#88a183] transition-colors"
              >
                Home
              </Link>
              <Link
                href="/how-it-works"
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-white/90 hover:text-[#88a183] transition-colors"
              >
                How It Works
              </Link>

              {/* Mobile Solutions */}
              <div>
                <button
                  onClick={() => setIsSolutionsOpen(!isSolutionsOpen)}
                  className="flex items-center gap-1 text-white/90 hover:text-[#88a183] transition-colors w-full"
                >
                  Solutions
                  <ChevronDown className={`w-4 h-4 transition-transform ${isSolutionsOpen ? "rotate-180" : ""}`} />
                </button>
                {isSolutionsOpen && (
                  <div className="ml-4 mt-2 flex flex-col gap-2">
                    <Link
                      href="/ai-receptionist"
                      className="text-white/70 hover:text-[#88a183] transition-colors text-sm"
                      onClick={() => setIsSolutionsOpen(false)}
                    >
                      AI Receptionist
                    </Link>
                    <Link
                      href="/automated-follow-ups"
                      className="text-white/70 hover:text-[#88a183] transition-colors text-sm"
                      onClick={() => setIsSolutionsOpen(false)}
                    >
                      Automated Follow-Ups
                    </Link>
                    <Link
                      href="/digital-ads"
                      className="text-white/70 hover:text-[#88a183] transition-colors text-sm"
                      onClick={() => setIsSolutionsOpen(false)}
                    >
                      Digital Ads
                    </Link>
                    <Link
                      href="/local-seo"
                      className="text-white/70 hover:text-[#88a183] transition-colors text-sm"
                      onClick={() => setIsSolutionsOpen(false)}
                    >
                      Local SEO
                    </Link>
                    <Link
                      href="/chatgpt-seo"
                      className="text-white/70 hover:text-[#88a183] transition-colors text-sm"
                      onClick={() => setIsSolutionsOpen(false)}
                    >
                      ChatGPT SEO (GEO)
                    </Link>
                    <Link
                      href="/crm-pipeline"
                      className="text-white/70 hover:text-[#88a183] transition-colors text-sm"
                      onClick={() => setIsSolutionsOpen(false)}
                    >
                      CRM + Pipeline Systems
                    </Link>
                    <Link
                      href="/website-development"
                      className="text-white/70 hover:text-[#88a183] transition-colors text-sm"
                      onClick={() => setIsSolutionsOpen(false)}
                    >
                      Website Development
                    </Link>
                    <Link
                      href="/reviews-engine"
                      className="text-white/70 hover:text-[#88a183] transition-colors text-sm"
                      onClick={() => setIsSolutionsOpen(false)}
                    >
                      Reviews Engine
                    </Link>
                  </div>
                )}
              </div>

              <Link
                href="/pricing"
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-white/90 hover:text-[#88a183] transition-colors"
              >
                Pricing
              </Link>
              <Link
                href="/case-studies"
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-white/90 hover:text-[#88a183] transition-colors"
              >
                Case Studies
              </Link>
              <Link
                href="/about"
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-white/90 hover:text-[#88a183] transition-colors"
              >
                About
              </Link>

              <a
                href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-2.5 bg-white text-black font-semibold rounded-lg hover:bg-white/90 transition-all duration-300 text-center"
              >
                Book Call
              </a>
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}
