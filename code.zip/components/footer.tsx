"use client"
import Image from "next/image"
import Link from "next/link"
import { Mail, Phone, MapPin } from "lucide-react"

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-gradient-to-b from-black to-black py-20">
      {/* Background glow */}
      <div className="absolute left-1/2 top-0 h-[400px] w-[400px] -translate-x-1/2 rounded-full bg-white/5 blur-[120px]" />

      <div className="relative mx-auto max-w-7xl px-4">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <Image
              src="/images/design-mode/Untitled%20design%20%2820%29.png"
              alt="StrivePoint Consulting"
              width={200}
              height={60}
              className="mb-6 h-auto w-[180px]"
            />
            <p className="mb-6 text-balance leading-relaxed text-white/60">
              AI-powered marketing automation that turns businesses into lead-generating machines.
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-white" />
                <a
                  href="mailto:info@strivepoint.co"
                  className="text-sm text-white/60 transition-colors hover:text-white"
                >
                  info@efreedom.com
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-white" />
                <a href="tel:+18186009069" className="text-sm text-white/60 transition-colors hover:text-white">
                  +1 (818) 600-9069
                </a>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-white" />
                <span className="text-sm text-white/60">Burbank, CA</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="mb-6 font-heading text-xl tracking-wide text-white">COMPANY</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/about" className="text-white/60 transition-colors hover:text-white">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/case-studies" className="text-white/60 transition-colors hover:text-white">
                  Case Studies
                </Link>
              </li>
              <li>
                <Link href="/how-it-works" className="text-white/60 transition-colors hover:text-white">
                  How We Do It
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="text-white/60 transition-colors hover:text-white">
                  Pricing
                </Link>
              </li>
              <li>
                <Link
                  href="https://api.leadconnectorhq.com/widget/booking/wNbNNXiKqWge7kOsK8RH"
                  className="text-white/60 transition-colors hover:text-white"
                >
                  Book Free Call
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-6 font-heading text-xl tracking-wide text-white">SOLUTIONS</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/ai-receptionist" className="text-white/60 transition-colors hover:text-white">
                  AI Receptionist
                </Link>
              </li>
              <li>
                <Link href="/automated-follow-ups" className="text-white/60 transition-colors hover:text-white">
                  Automated Follow-Ups
                </Link>
              </li>
              <li>
                <Link href="/digital-ads" className="text-white/60 transition-colors hover:text-white">
                  Digital Ads & Funnels
                </Link>
              </li>
              <li>
                <Link href="/local-seo" className="text-white/60 transition-colors hover:text-white">
                  Local SEO
                </Link>
              </li>
              <li>
                <Link href="/website-development" className="text-white/60 transition-colors hover:text-white">
                  Website Rebuild
                </Link>
              </li>
              <li>
                <Link href="/reviews-engine" className="text-white/60 transition-colors hover:text-white">
                  Reviews Engine
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-6 font-heading text-xl tracking-wide text-white">RESOURCES</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/faq" className="text-white/60 transition-colors hover:text-white">
                  FAQs
                </Link>
              </li>
              <li>
                <Link href="/affiliate" className="text-white/60 transition-colors hover:text-white">
                  Affiliate Program
                </Link>
              </li>
              <li>
                <Link href="/support" className="text-white/60 transition-colors hover:text-white">
                  Support
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-white/60 transition-colors hover:text-white">
                  Terms & Privacy
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 border-t border-white/10 pt-8">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <p className="text-sm text-white/40">© 2025 StrivePoint Consulting. All rights reserved.</p>
            <div className="flex gap-6 text-sm">
              <Link href="/terms" className="text-white/40 transition-colors hover:text-white">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-white/40 transition-colors hover:text-white">
                Terms of Service
              </Link>
              <Link href="/terms" className="text-white/40 transition-colors hover:text-white">
                Cookie Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
