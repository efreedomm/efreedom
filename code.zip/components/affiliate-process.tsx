"use client"

import { CheckCircle2, Link2, Share2 } from "lucide-react"

const steps = [
  {
    icon: CheckCircle2,
    title: "Sign Up",
    description:
      "Join the eFreedom Partner Program in minutes. Get your unique referral link and access to marketing materials.",
  },
  {
    icon: Link2,
    title: "Share & Promote",
    description:
      "Share your referral link with your network. Use our proven marketing materials and strategies to maximize conversions.",
  },
  {
    icon: Share2,
    title: "Earn Commissions",
    description:
      "Earn up to 20% recurring commissions on all referred clients. Get paid monthly via your preferred payment method.",
  },
]

export function AffiliateProcess() {
  return (
    <section className="relative overflow-hidden bg-black py-24">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(255,255,255,0.05),transparent_60%)]" />

      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full opacity-30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${5 + Math.random() * 10}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
      </div>

      <div className="relative mx-auto max-w-7xl px-4">
        {/* Header */}
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-4xl font-bold text-white md:text-5xl">How It Works</h2>
          <p className="mx-auto max-w-2xl text-lg text-white/70">
            Join the eFreedom Partner Program and start earning recurring commissions
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid gap-8 md:grid-cols-3">
          {steps.map((step, index) => {
            const Icon = step.icon
            return (
              <div
                key={index}
                className="group relative rounded-2xl border border-white/20 bg-white/5 p-8 backdrop-blur-sm transition-all duration-300 hover:border-white/40 hover:bg-white/10"
              >
                {/* Step number */}
                <div className="mb-6 inline-flex h-12 w-12 items-center justify-center rounded-full bg-white text-black text-xl font-bold">
                  {index + 1}
                </div>

                {/* Icon */}
                <div className="mb-4 inline-flex rounded-xl bg-white/10 p-3">
                  <Icon className="h-6 w-6 text-[#C6A564]" />
                </div>

                {/* Content */}
                <h3 className="mb-3 text-2xl font-bold text-white">{step.title}</h3>
                <p className="text-white/70">{step.description}</p>
              </div>
            )
          })}
        </div>

        {/* Benefits Section */}
        <div className="mt-20">
          <h3 className="mb-12 text-center text-3xl font-bold text-white">Partner Benefits</h3>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {/* Benefit 1 */}
            <div className="rounded-xl border border-white/20 bg-white/5 p-6 backdrop-blur-sm">
              <div className="mb-4 text-4xl">💰</div>
              <h4 className="mb-2 text-xl font-bold text-white">up to 20% for set up</h4>
              <p className="text-sm text-white/70">Earn commissions for the lifetime of each client</p>
            </div>

            {/* Benefit 2 */}
            <div className="rounded-xl border border-white/20 bg-white/5 p-6 backdrop-blur-sm">
              <div className="mb-4 text-4xl">📊</div>
              <h4 className="mb-2 text-xl font-bold text-white">Real-Time Dashboard</h4>
              <p className="text-sm text-white/70">Track clicks, conversions, and earnings in real-time</p>
            </div>

            {/* Benefit 3 */}
            <div className="rounded-xl border border-white/20 bg-white/5 p-6 backdrop-blur-sm">
              <div className="mb-4 text-4xl">🎯</div>
              <h4 className="mb-2 text-xl font-bold text-white">Marketing Support</h4>
              <p className="text-sm text-white/70">Access proven templates, graphics, and copy that converts</p>
            </div>

            {/* Benefit 4 */}
            <div className="rounded-xl border border-white/20 bg-white/5 p-6 backdrop-blur-sm">
              <div className="mb-4 text-4xl">🤝</div>
              <h4 className="mb-2 text-xl font-bold text-white">Dedicated Support</h4>
              <p className="text-sm text-white/70">Get help from our partner success team whenever you need it</p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <a
            href="/affiliate"
            className="inline-flex items-center gap-2 rounded-full bg-white px-8 py-4 text-lg font-semibold text-black transition-all hover:scale-105 hover:shadow-xl"
          >
            Become a Partner
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </a>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0) translateX(0);
          }
          50% {
            transform: translateY(-20px) translateX(10px);
          }
        }
      `}</style>
    </section>
  )
}
