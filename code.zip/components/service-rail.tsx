"use client"

import { Sparkles, TrendingUp, Phone, Zap, Target } from "lucide-react"

const services = [
  {
    icon: Sparkles,
    title: "AI Strategy",
    description: "Custom AI roadmaps tailored to your business goals",
  },
  {
    icon: TrendingUp,
    title: "Growth Analytics",
    description: "Data-driven insights that fuel exponential growth",
  },
  {
    icon: Phone,
    title: "24/7 AI Support",
    description: "Intelligent automation that never sleeps",
  },
  {
    icon: Zap,
    title: "Rapid Deployment",
    description: "From strategy to execution in record time",
  },
  {
    icon: Target,
    title: "Precision Targeting",
    description: "Reach the right audience at the right time",
  },
]

export function ServiceRail() {
  return (
    <section className="relative overflow-hidden bg-[#0B121D] py-24">
      {/* Background glow */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#C6A564]/5 via-transparent to-[#C6A564]/5" />

      <div className="relative">
        {/* Section Header */}
        <div className="mb-16 px-4 text-center">
          <div>
            <h2 className="font-heading text-4xl tracking-wide text-white md:text-5xl lg:text-6xl">
              OUR <span className="text-[#C6A564]">CAPABILITIES</span>
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-balance text-lg text-white/70">
              Comprehensive solutions powered by cutting-edge AI technology
            </p>
          </div>
        </div>

        {/* Scrolling Rail */}
        <div className="flex gap-6 px-4 overflow-x-auto">
          {/* Duplicate services for infinite scroll effect */}
          {[...services, ...services].map((service, index) => (
            <div
              key={index}
              className="group relative min-w-[320px] overflow-hidden rounded-2xl border border-[#C6A564]/20 bg-gradient-to-br from-[#1A2332] to-[#0B121D] p-8 backdrop-blur-sm transition-all hover:border-[#C6A564]/40 hover:shadow-[0_0_30px_rgba(198,165,100,0.15)]"
            >
              {/* Glow effect on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#C6A564]/0 to-[#C6A564]/0 opacity-0 transition-opacity duration-500 group-hover:from-[#C6A564]/5 group-hover:to-transparent group-hover:opacity-100" />

              <div className="relative">
                {/* Icon */}
                <div className="mb-6 inline-flex rounded-xl bg-[#C6A564]/10 p-4 transition-all group-hover:bg-[#C6A564]/20">
                  <service.icon className="h-8 w-8 text-[#C6A564]" />
                </div>

                {/* Content */}
                <h3 className="mb-3 font-heading text-2xl tracking-wide text-white">{service.title}</h3>
                <p className="text-balance leading-relaxed text-white/70">{service.description}</p>

                {/* Decorative line */}
                <div className="mt-6 h-1 w-12 rounded-full bg-gradient-to-r from-[#C6A564] to-transparent transition-all group-hover:w-20" />
              </div>
            </div>
          ))}
        </div>

        {/* Gradient overlays for fade effect */}
        <div className="pointer-events-none absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-[#0B121D] to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-[#0B121D] to-transparent" />
      </div>
    </section>
  )
}
