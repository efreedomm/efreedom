"use client"

import { useState } from "react"
import { TrendingUp, Clock, DollarSign } from "lucide-react"
import Image from "next/image"

export const caseStudies = [
  {
    company: "Summit Digital Solutions",
    industry: "Technology Services",
    challenge:
      "Missed calls after hours, slow follow-ups, and inconsistent reviews leading to lost opportunities in peak season.",
    solution:
      "AI Call Receptionist (24/7) + missed-call text back, CRM pipeline with SMS/email nurture, Google Business Profile cleanup, review automation.",
    results: [
      { icon: TrendingUp, label: "New Clients (60d)", value: "41", change: "+41 new" },
      { icon: Clock, label: "First Response", value: "0:32s", change: "-85%" },
      { icon: DollarSign, label: "Close Rate", value: "44%", change: "+27%" },
    ],
    image: "/case-hvac-high-performance-mechanical.jpg",
    website: "https://highperformancemechanical.com",
  },
  {
    company: "Prestige Professional Services",
    industry: "Business Consulting",
    challenge: "Manual quoting and slow follow-ups causing lost bids; site had no clear request-a-quote flow.",
    solution:
      "Quote-request funnel with portfolio gallery, AI chat assistant, CRM stages from bid→delivery, automated SMS/email follow-ups, light local ads.",
    results: [
      { icon: TrendingUp, label: "New Projects (45d)", value: "19", change: "+19 new" },
      { icon: Clock, label: "Quote Response", value: "6 min", change: "-70%" },
      { icon: DollarSign, label: "Close Rate", value: "31%", change: "+14pp" },
    ],
    image: "/case-millwork-alpine-woodworks.jpg",
  },
]

export function CaseStudiesSection() {
  const [activeIndex, setActiveIndex] = useState(0)

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#0B121D] to-[#1A2332] py-32">
      {/* Radial glow */}
      <div className="absolute right-0 top-1/4 h-[800px] w-[800px] rounded-full bg-[#C6A564]/5 blur-[150px]" />

      <div className="relative mx-auto max-w-7xl px-4">
        {/* Header */}
        <div className="mb-20 text-center">
          <div>
            <h2 className="font-heading text-4xl tracking-wide text-white md:text-5xl lg:text-6xl">
              PROVEN <span className="text-[#C6A564]">SUCCESS STORIES</span>
            </h2>
            <p className="mx-auto mt-6 max-w-3xl text-balance text-lg leading-relaxed text-white/70">
              Real transformations from businesses that partnered with StrivePoint
            </p>
          </div>
        </div>

        {/* Case Study Tabs */}
        <div className="mb-12 flex flex-wrap justify-center gap-4">
          {caseStudies.map((study, index) => (
            <button
              key={index}
              onClick={() => setActiveIndex(index)}
              className={`rounded-xl px-6 py-3 font-heading text-lg tracking-wide transition-all ${
                activeIndex === index
                  ? "bg-[#C6A564] text-[#0B121D] shadow-[0_0_30px_rgba(198,165,100,0.3)]"
                  : "border border-[#C6A564]/30 text-white/70 hover:border-[#C6A564]/50 hover:text-white"
              }`}
            >
              {study.company}
            </button>
          ))}
        </div>

        {/* Active Case Study */}
        <div
          key={activeIndex}
          className="overflow-hidden rounded-3xl border border-[#C6A564]/20 bg-gradient-to-br from-[#1A2332]/90 to-[#0B121D]/90 backdrop-blur-sm"
        >
          <div className="grid gap-8 lg:grid-cols-2">
            {/* Image */}
            <div className="relative h-[400px] overflow-hidden lg:h-auto">
              <Image
                src={caseStudies[activeIndex].image || "/placeholder.svg"}
                alt={caseStudies[activeIndex].company}
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-[#0B121D]/50 to-transparent" />
            </div>

            {/* Content */}
            <div className="p-8 lg:p-12">
              {/* Company Info */}
              <div className="mb-6">
                <div className="mb-2 inline-block rounded-full bg-[#C6A564]/10 px-4 py-1 text-sm text-[#C6A564]">
                  {caseStudies[activeIndex].industry}
                </div>
                <h3 className="font-heading text-3xl tracking-wide text-white md:text-4xl">
                  {caseStudies[activeIndex].company}
                </h3>
              </div>

              {/* Challenge */}
              <div className="mb-6">
                <h4 className="mb-2 font-heading text-xl text-[#C6A564]">THE CHALLENGE</h4>
                <p className="leading-relaxed text-white/70">{caseStudies[activeIndex].challenge}</p>
              </div>

              {/* Solution */}
              <div className="mb-8">
                <h4 className="mb-2 font-heading text-xl text-[#C6A564]">OUR SOLUTION</h4>
                <p className="leading-relaxed text-white/70">{caseStudies[activeIndex].solution}</p>
              </div>

              {/* Results */}
              <div>
                <h4 className="mb-4 font-heading text-xl text-[#C6A564]">THE RESULTS</h4>
                <div className="grid gap-4 sm:grid-cols-3">
                  {caseStudies[activeIndex].results.map((result, index) => (
                    <div key={index} className="rounded-xl border border-[#C6A564]/20 bg-[#0B121D]/50 p-4">
                      {result.icon && <result.icon className="mb-2 h-6 w-6 text-[#C6A564]" />}
                      <div className="mb-1 text-xs text-white/60">{result.label}</div>
                      <div className="mb-1 font-heading text-2xl text-white">{result.value}</div>
                      <div className="text-xs font-medium text-[#C6A564]">{result.change}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* CTA */}
              <div className="mt-8 flex justify-center">
                {caseStudies[activeIndex].website && (
                  <a
                    href={caseStudies[activeIndex].website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group inline-flex items-center gap-2 text-sm text-white/70 transition-colors hover:text-[#C6A564]"
                  >
                    <span>Visit the website we built for them</span>
                    <svg
                      className="h-4 w-4 transition-transform group-hover:translate-x-1"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
